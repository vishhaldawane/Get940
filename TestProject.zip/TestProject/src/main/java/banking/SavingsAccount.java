package banking;

import javax.management.RuntimeErrorException;

public class SavingsAccount {
	private int accountNumber;
	private String accountHolder;
	private double accountBalance;
	
	
	public SavingsAccount() {
		super();
		System.out.println("SavingsAccount()");
	}

	public SavingsAccount(int accountNumber, String accountHolder, double accountBalance) {
		super();
		System.out.println("SavingsAccount(int,String,double)");
		this.accountNumber = accountNumber;
		this.accountHolder = accountHolder;
		this.accountBalance = accountBalance;
	}

	@Override
	public String toString() {
		return "SvingsAccount [accountNumber=" + accountNumber + ", accountHolder=" + accountHolder
				+ ", accountBalance=" + accountBalance + "]";
	}
	
	public void withdraw(double amountToWithdraw) {
		if(amountToWithdraw < 0) {
			throw new RuntimeException("Amount cannot be negative..");
		}
		this.accountBalance = this.accountBalance - amountToWithdraw;
		//this.accountBalance=this.accountBalance-1;
	}
	
	public double getBalance() {
		return accountBalance;
	}
	
	public void deposit(double amountToDeposit) {
		this.accountBalance = this.accountBalance + amountToDeposit;
	}
	
}
