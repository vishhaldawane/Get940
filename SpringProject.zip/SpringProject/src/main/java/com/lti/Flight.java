package com.lti;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name="flights")
public class Flight { // upcoming pojo for JPA

	@Id
	@GeneratedValue
	@Column(name="FLIGHT_NO")
	private int flightNumber;
	
	@Column(name="FLIGHT_NAME", length=20)
	private String flightName;
	
	@Column(name="SOURCE_CITY", length=20)
	private String flightSource;
	
	@Column(name="DEST_CITY", length=20)
	private String flightDestination;
	
	public Flight() {
		System.out.println("Flight ctor...");
	}
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getFlightSource() {
		return flightSource;
	}
	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}
	public String getFlightDestination() {
		return flightDestination;
	}
	public void setFlightDestination(String flightDestination) {
		this.flightDestination = flightDestination;
	}
	
	
}
