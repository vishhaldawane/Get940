package com.lti;

import java.util.Scanner;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

class Piston {
	String type;
	Piston(String type) {		this.type = type;
		System.out.println("Piston constucted...");
	}
	void firing() {	System.out.println("firing "+type +" piston..");}
}
class Engine {
	Piston p;
		Engine(Piston x) { p = x; 
			System.out.println("Engine constucted...");
		}
		void ignite() {	p.firing();
			System.out.println("Igniting Engine...");
		}
}
class AlloyedWheel extends Wheel { }
class MacWheel extends Wheel { }

class Wheel  // creating proxy for us 
{
	float radius;
	Wheel() {
		System.out.println("Wheel() no arg constructor called...");
	}
	public float getRadius() {	return radius;	}
	public void setRadius(float radius) {
		System.out.println("Setting Radius of the Wheel..."+radius);
		this.radius = radius;
	}
	public void init() { //EntityManagerFactory, EntityManager Loading...
		System.out.println("init().. Wheel...");
	}
	public void destroy() { //closing of the EntityManager, EntityManagerFactory,
		System.out.println("destroy().. Wheel...");
	}
	void show() {
		System.out.println("Wheel : "+radius);
	}
}


class Car { //extends isA
	Engine e;  // hasA   usesA producesA
	Wheel wheelRef;
	/*Car(Engine x) { e = x;
		System.out.println("Car constucted...");
	}*/
	public void setWheel(Wheel w) { //wheel is the property
		System.out.println("setCar(Wheel w) : Setting the car....got the wheel.."+w.getRadius());
		wheelRef = w;
	}
	void startCar() { e.ignite(); System.out.println("Car started");}
}
public class SpringTest {
	public static void main(String[] args) {

		System.out.println("loading spring container...");
		AbstractApplicationContext ctx = new 
				ClassPathXmlApplicationContext("spring1.xml");
		System.out.println("loaded the container..."+ctx);
		/*Car myCar1 = (Car) ctx.getBean("c"); // here c is the id of the bean
		Car myCar2 = (Car) ctx.getBean("c"); // here c is the id of the bean
		Car myCar3 = (Car) ctx.getBean("c"); // here c is the id of the bean
		
		myCar1.startCar();
		myCar2.startCar();
		myCar3.startCar();
		
		System.out.println("myCar1 : "+myCar1.hashCode());
		System.out.println("myCar2 : "+myCar2.hashCode());
		System.out.println("myCar3 : "+myCar3.hashCode());
		*/
		
		/*Piston p1 = new Piston("Dual Spark");
		Engine e1 = new Engine(p1);
		Car c1 = new Car(e1);
		*/
		Wheel w1 = (Wheel) ctx.getBean("w");
		Wheel w2 = (Wheel) ctx.getBean("w");
		
		System.out.println("Wheel radius : "+w1.getRadius());
		System.out.println("Wheel radius : "+w2.getRadius());
		
		
		Scanner scan = new Scanner(System.in);
		w1.setRadius(scan.nextFloat());
		w2.setRadius(scan.nextFloat());
		
		System.out.println("Wheel radius : "+w1.getRadius());
		System.out.println("Wheel radius : "+w2.getRadius());
		
		w1.show();
		w2.show();
		
		//conn = drivermanager....
		//st = conn.createStatement
		//rs = st.executeQuery...
		
		//rs.close(),
		//st.close();
		//conn.close(), 
		
		System.out.println("End of main");
		ctx.registerShutdownHook(); //carom board is a context for all the four player
		//1horizontal line for player1, config,
		//2horizontal line for player2, config,
		
		//In the morning -> Open Office - JVM started
		//-> switchOn Main Electricity - ctx loaded
			//working hours..here	ctx.getBean...

		// switchOff Main Electricity  - ctx to be shutdown too
		//closing the office - JVM Shutdown in progress...
	} //closing JVM
}
