package com.vishal.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfullAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
