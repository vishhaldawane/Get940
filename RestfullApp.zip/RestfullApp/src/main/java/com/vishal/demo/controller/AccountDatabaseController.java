package com.vishal.demo.controller;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vishal.demo.entity.Account;
import com.vishal.demo.services.myexceptions.AccountAlreadyPresentException;
import com.vishal.demo.services.myexceptions.AccountNotPresentException;
import com.vishal.demo.services.AccountDatabaseService;
import com.vishal.demo.services.AccountService;

@RestController
@RequestMapping("/bankdb") // http://ip:port/bankdb
public class AccountDatabaseController {

	@Autowired
	AccountDatabaseService accountService;

	
	@GetMapping
	public String home() { 
		return "<h1> Welcome to My Bank </h1>";
	}
	
	@GetMapping("/greet") //http://ip:port/bankdb/greet
	public String home2() { 
		return "<h1> Welcome to My Bank2 </h1>";
	}
	@GetMapping("/accounts")// http://ip:port/bankdb/accounts
	public List<Account> getAllAccounts()
	{
		return accountService.fetchAllAccounts();
	}
	
	@GetMapping("/accounts/{id}")// http://ip:port/bank/accounts/101
	public ResponseEntity<?> getSingleAccount(@PathVariable("id") int acno, @RequestHeader("myuserpass") String mypassword)
	{
		try
		{
			System.out.println("myuserpass : "+mypassword);
			Account accObj =  accountService.fetchSingleAccount(acno);
			return ResponseEntity.ok(accObj);
		}
		catch(AccountNotPresentException acNtPresentEx) {
			 return ResponseEntity.status(HttpStatus.NOT_FOUND)
					 .body(acNtPresentEx.getMessage());
		} 
	}
	
	@PostMapping("/accounts/add") //ctrl +shift + M
	public ResponseEntity<?> addSingleAccount(@RequestBody Account accObjToAdd)
	{
		try
		{
			accountService.addSingleAccount(accObjToAdd);
			return ResponseEntity.ok(accObjToAdd);
		}
		catch(AccountAlreadyPresentException accPresentEx) {
			return ResponseEntity.status(HttpStatus.CONFLICT)
					.body(accPresentEx.getMessage());
		}
	}
	
	@PutMapping("/accounts/update") //ctrl +shift + M
	public ResponseEntity<?> updateSingleAccount(@RequestBody Account accObjToModify)
	{
		try
		{
			accountService.updateSingleAccount(accObjToModify);
			return ResponseEntity.ok(accObjToModify);
		}
		catch(AccountNotPresentException accNotPresentEx) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(accNotPresentEx.getMessage());
		}
	}
	
	@DeleteMapping("/accounts/delete/{id}") //ctrl +shift + M
	public ResponseEntity<?> deleteSingleAccount(@PathVariable("id") int accNumberToDelete)
	{
		try
		{
			accountService.deleteSingleAccount(accNumberToDelete);
			return ResponseEntity.ok("Account deleted : "+accNumberToDelete);
		}
		catch(AccountNotPresentException accNotPresentEx) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(accNotPresentEx.getMessage());
		}
	}
	
}
