package com.vishal.demo.services.myexceptions;

public class AccountAlreadyPresentException extends RuntimeException
{
	public AccountAlreadyPresentException(String msg) {
		super(msg);
	}
}
