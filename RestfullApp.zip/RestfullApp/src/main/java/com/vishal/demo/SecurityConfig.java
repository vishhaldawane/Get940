/*package com.vishal.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import com.vishal.demo.services.CustomUserDetailsService;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Autowired
	CustomUserDetailsService customUserDetailsService;
	
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        System.out.println("securityFilterChain(HttpSecurity http)");
    	http
    		.cors().and()
            .csrf().disable()
            .authorizeHttpRequests(authorize -> authorize
                .antMatchers("/public/**").permitAll() // Allow public access
                .anyRequest().authenticated() // Require authentication for all other requests
            )
            .httpBasic(Customizer.withDefaults()); // Enable basic authentication
        return http.build();
    }
    
    
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    	http
        .httpBasic()
            .and()
        .authorizeRequests()
            .antMatchers(HttpMethod.POST, "localhost:8080/bank").permitAll();
    http
        .httpBasic()
            .and()
        .authorizeRequests()
            .antMatchers(HttpMethod.POST, "localhost:8080/bankdb/accounts/add").permitAll()
            .antMatchers(HttpMethod.GET, "localhost:8080/bankdb/accounts").hasAuthority("ADMIN");
    http
        .csrf().disable();
    return http.build();

    }
   

    @Bean
    public UserDetailsService userDetailsService() {
        System.out.println("userDetailsService()");
    	// Configure in-memory or database-backed user details service
        // Example: In-memory user
        UserDetails user = User.withDefaultPasswordEncoder()
            .username("user")
            .password("password")
            .roles("USER")
            .build();
        return new InMemoryUserDetailsManager(user);
    }
    
   
    @Bean
    public UserDetails userDetailsService2() {
        System.out.println("userDetailsService()");
    	
        return customUserDetailsService.loadUserByUsername("111");
    }
    
}
*/



