/*package com.vishal.demo.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.vishal.demo.entity.Account;
import com.vishal.demo.repositories.AccountDatabaseRepository;

@Service
 public class CustomUserDetailsService implements UserDetailsService {
        @Autowired
        private AccountDatabaseRepository accountRepository;

        @Override
        public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
            Account account = accountRepository.findById(Integer.parseInt(username))
                    .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
            // Convert your User entity to Spring Security's UserDetails
            return new org.springframework.security.core.userdetails.User(
                    String.valueOf(account.getAccountNumber()), account.getAccountHolder(), new ArrayList<>()); // Add authorities
        }
    }*/
