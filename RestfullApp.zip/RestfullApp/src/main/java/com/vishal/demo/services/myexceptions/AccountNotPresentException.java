package com.vishal.demo.services.myexceptions;

public class AccountNotPresentException extends RuntimeException
{
	public AccountNotPresentException(String msg) {
		super(msg);
	}
}
