package com.vishal.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfullAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfullAppApplication.class, args);
	}

}
