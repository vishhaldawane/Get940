package com.vishal.demo.services;

import java.util.List;
import java.util.Optional;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vishal.demo.entity.Account;
import com.vishal.demo.repositories.AccountDatabaseRepository;
import com.vishal.demo.repositories.AccountRepository;
import com.vishal.demo.services.myexceptions.AccountAlreadyPresentException;
import com.vishal.demo.services.myexceptions.AccountNotPresentException;

@Service
public class AccountDatabaseService {//suppose to take BL decisions

	@Autowired
	AccountDatabaseRepository accountRepository;
	
	public List<Account> fetchAllAccounts() {
		return accountRepository.findAll();
	}
	
	public Account fetchSingleAccount(int x) throws AccountNotPresentException {
		
		  
		  Account account = accountRepository.findById(x)
	                .orElseThrow(() -> new AccountNotPresentException("Account not found with id: " + x));
			return account;
		
	}
	
	public Account addSingleAccount(Account accObjToAdd) {
		Optional<Account> accObjFound = accountRepository.findById(accObjToAdd.getAccountNumber());
		if(accObjFound.isPresent()) {
			
			throw new AccountAlreadyPresentException("This Account Number already exists : "+accObjToAdd.getAccountNumber());
		}
		else {
			accountRepository.save(accObjToAdd);
		}
		return accObjToAdd;
	}
	
	public Account updateSingleAccount(Account accObjToModify) {
		Optional<Account> accObjFound = accountRepository.findById(accObjToModify.getAccountNumber());

		if(accObjFound.isPresent()) {
			accountRepository.save(accObjToModify);
		}
		else {
			throw new AccountNotPresentException("This Account Number does not exists : "+accObjToModify.getAccountNumber());

		}
		return accObjToModify;
	}
	
	public void deleteSingleAccount(int accNumberToDelete) {
		Optional<Account> accObjFound = accountRepository.findById(accNumberToDelete);
		if(accObjFound.isPresent()) {
			accountRepository.deleteById(accNumberToDelete);
		}
		else {
			throw new AccountNotPresentException("This Account Number does not exists : "+accNumberToDelete);

		}
	}
}
