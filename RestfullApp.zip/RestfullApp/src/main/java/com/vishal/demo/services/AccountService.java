package com.vishal.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vishal.demo.entity.Account;
import com.vishal.demo.repositories.AccountRepository;
import com.vishal.demo.services.myexceptions.AccountAlreadyPresentException;
import com.vishal.demo.services.myexceptions.AccountNotPresentException;

@Service
public class AccountService {//suppose to take BL decisions

	@Autowired
	AccountRepository accountRepository;
	
	public List<Account> fetchAllAccounts() {
		return accountRepository.selectAllAccounts();
	}
	
	public Account fetchSingleAccount(int x) {
		
		Account accRef =  accountRepository.findAccountById(x);
		if(accRef != null) {
			return accRef;
		}
		else {
			throw new AccountNotPresentException("This account does not exists : "+x);
		}
	}
	
	public Account addSingleAccount(Account accObjToAdd) {
		Account accObjFound = accountRepository.findAccountById(accObjToAdd.getAccountNumber());
		if(accObjFound!=null) {
			throw new AccountAlreadyPresentException("This Account Number already exists : "+accObjToAdd.getAccountNumber());
		}
		else {
			accountRepository.saveNewAccount(accObjToAdd);
		}
		return accObjToAdd;
	}
	
	public Account updateSingleAccount(Account accObjToModify) {
		Account accObjFound = accountRepository.findAccountById(accObjToModify.getAccountNumber());
		if(accObjFound!=null) {
			accountRepository.updateAccount(accObjToModify);
		}
		else {
			throw new AccountNotPresentException("This Account Number does not exists : "+accObjToModify.getAccountNumber());

		}
		return accObjToModify;
	}
	
	public void deleteSingleAccount(int accNumberToDelete) {
		Account accObjFound = accountRepository.findAccountById(accNumberToDelete);
		if(accObjFound!=null) {
			accountRepository.deleteAccount(accNumberToDelete);
		}
		else {
			throw new AccountNotPresentException("This Account Number does not exists : "+accNumberToDelete);

		}
	}
}
