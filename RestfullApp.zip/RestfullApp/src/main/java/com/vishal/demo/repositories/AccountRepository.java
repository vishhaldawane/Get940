package com.vishal.demo.repositories;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.vishal.demo.entity.Account;

@Repository
public class AccountRepository { //provide the crud | no exception handling | no business handling

	List<Account> allAcctsList = new ArrayList<Account>(); //empty growable array
	
	public AccountRepository() {//runs only once 
		Account acc1 = new Account();
		acc1.setAccountNumber(101);acc1.setAccountHolder("Jack");acc1.setAccountBalance(500000);

		Account acc2 = new Account();
		acc2.setAccountNumber(102);		acc2.setAccountHolder("Janet");	acc2.setAccountBalance(600000);

		Account acc3 = new Account();
		acc3.setAccountNumber(103);		acc3.setAccountHolder("Jane");		acc3.setAccountBalance(700000);

		Account acc4 = new Account();
		acc4.setAccountNumber(104);		acc4.setAccountHolder("Julie");		acc4.setAccountBalance(800000);

		Account acc5 = new Account();
		acc5.setAccountNumber(105);		acc5.setAccountHolder("Joe");	acc5.setAccountBalance(900000);
		allAcctsList.add(acc1);
		allAcctsList.add(acc2);
		allAcctsList.add(acc3);
		allAcctsList.add(acc4);
		allAcctsList.add(acc5);
		
		
	}
	
	public List<Account> selectAllAccounts()
	{
		return allAcctsList;
	}
	
	public Account findAccountById(int acno) {
		for(Account accObj : allAcctsList) {
			if(accObj.getAccountNumber() == acno) {
				return accObj;
			}
		}
		return null;
	}
	public void saveNewAccount(Account newAccObj) {
		
		allAcctsList.add(newAccObj);
	}
	public void updateAccount(Account accObjectToModify) {
		for(Account accObj : allAcctsList) {
			if(accObj.getAccountNumber() == accObjectToModify.getAccountNumber()) {
				allAcctsList.remove(accObj);
				allAcctsList.add(accObjectToModify);
				break;
			}
		}
	}
	public void deleteAccount(int accNumberToDelete) {
		for(Account accObj : allAcctsList) {
			if(accObj.getAccountNumber() == accNumberToDelete) {
				allAcctsList.remove(accObj);
				break;
			}
		}
	}
}






