package jungle;
import jungle.cave.*;
import jungle.river.Crocodile;
import jungle.tree.Bird;

public class MainClass {

	public static void main(String[] args) {
		System.out.println("Begin main");
		//Bird cannot be resolved to a type
		/*Bird b = new Bird();
		b.layEggs();
		Crocodile c = new Crocodile();
		c.swim();
		Tiger t = new Tiger();
		t.jump();
		WhiteTiger wt = new WhiteTiger();
		wt.jump();
		wt.jumpAcrossSnow();
		wt.giveBirth();*/
		//Lion lionKing = new Lion();
		//lionKing.roar();
		//Tiger t = new Tiger();
		//t.jump();
		//WhiteTiger wt = new WhiteTiger();
		//wt.jumpAcrossSnow();
		//Bird b = new Bird();
		//b.layEggs();
		Tiger t = new WhiteTiger();
		t.jump();
		
		System.out.println("defaultA   : "+t.defaultA);
		System.out.println("privateA   : "+t.privateA); //The field Tiger.privateA is not visible
		System.out.println("protectedA : "+t.protectedA);//via the t reference which is not a Bird
		System.out.println("public A   : "+t.publicA);
		System.out.println("End main");
		
	}

}
