package jungle.cave;

public interface Mammal {
	void giveBirth();
}
