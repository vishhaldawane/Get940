package jungle.cave;

//The public type WhiteTiger 
//must be defined in its own file
public class WhiteTiger extends Tiger implements Mammal
{
	/*  int defaultA=100;
	private   int privateA=200;
	protected int protectedA=300;
	public    int publicA=400;
	*/
	public void jump() {
		System.out.println("White tiger jumping across the snowland...");
		System.out.println("defaultA   : "+defaultA);
		System.out.println("privateA   : "+privateA); //The field Tiger.privateA is not visible
		System.out.println("protectedA : "+protectedA);
		System.out.println("public A   : "+publicA);
		
	}
	public void giveBirth() {
		System.out.println("WhiteTiger is giving birth....");
	}
}