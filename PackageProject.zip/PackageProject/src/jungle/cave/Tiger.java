package jungle.cave;
//Illegal modifier for the class Tiger
//only public, abstract & final are permitted
public class Tiger {
			  int defaultA=10;
	private   int privateA=20;
	protected int protectedA=30;
	public    int publicA=40;
	
	public Tiger() {
		System.out.println("Tiger ctor..");
	}
	public void jump() {
		System.out.println("Tiger is jumping...");
		System.out.println("Tiger:defaultA   : "+defaultA);
		System.out.println("Tiger:privateA   : "+privateA);
		System.out.println("Tiger:protectedA : "+protectedA);
		System.out.println("Tiger:public A   : "+publicA);
	}
}
