package jungle.cave;

public class Lion {
	public Lion() {
		System.out.println("Lion ctor..");
	}
	public void roar() {
		System.out.println("Lion is roaring...");
		Tiger t = new Tiger();
		System.out.println("defaultA   : "+t.defaultA);
		//System.out.println("privateA   : "+t.privateA); //The field Tiger.privateA is not visible
		System.out.println("protectedA : "+t.protectedA);
		System.out.println("public A   : "+t.publicA);
			
	}
}
