package jungle.tree;

class Monkey {
	Monkey() {
		System.out.println("Monkey ctor..");
	}
	void swinging() {
		System.out.println("Monkey is swinging...");
	}
}
