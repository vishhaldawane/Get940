package jungle.tree;

import jungle.cave.Tiger;

//making a class as public 
//does not mean all contents are public

public class Bird  {
	public Bird() {
		System.out.println("Bird ctor..");
	}
	public void layEggs() {
		System.out.println("Bird is laying eggs...");
		//Tiger t = new Tiger();
	//	System.out.println("defaultA   : "+defaultA);
//		System.out.println("privateA   : "+t.privateA); //The field Tiger.privateA is not visible
	//	System.out.println("protectedA : "+t.protectedA);//via the t reference which is not a Bird
//		System.out.println("  protectedA : "+protectedA);//this is via the extends keyword gateway
//		System.out.println("t public A   : "+t.publicA);
	//	System.out.println("  public A   : "+publicA);
		
	}
}
