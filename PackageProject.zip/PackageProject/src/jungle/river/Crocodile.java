package jungle.river;

public class Crocodile {
	public Crocodile() {
		System.out.println("Crocodile ctor..");
	}
	public void swim() {
		System.out.println("Crocodile is swiming...");
	}
}
