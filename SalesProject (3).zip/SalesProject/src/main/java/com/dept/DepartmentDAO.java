package com.dept;

import java.util.ArrayList;
import java.util.List;

public interface DepartmentDAO { //2 POJI
	void insertDepartment(Department dept);
	Department selectDepartment(int deptno);
	List<Department> selectAllDepartments();
	void updateDepartment(Department dept);
	void deleteDepartment(Department dept);	
}
