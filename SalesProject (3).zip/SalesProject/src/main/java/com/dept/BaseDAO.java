package com.dept;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;

public class BaseDAO {
	
	SessionFactory factory;
	
	BaseDAO() {
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		System.out.println("=>Service Registry.."+serviceRegistry);
		Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
		System.out.println("=>Meta Data.."+metadata);
		
		factory= metadata.getSessionFactoryBuilder().build();
		System.out.println("=>session factory.."+factory);
	}
	void save(Object o) { //user defined method here
		Session session = factory.getCurrentSession();
		System.out.println("=>session.."+session);
		Transaction tx = session.beginTransaction();
		System.out.println("=>transaction.."+tx);
		session.save(o); //session.save - sql insert query
		tx.commit();
	}
}
