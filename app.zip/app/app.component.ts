import { Component } from '@angular/core';

//in angular is it known as decorator |in java it is

@Component({ 
  selector: 'app-root', /*this would be the tag name*/ 
  templateUrl: './app.component.html', /* VIEW */
  styleUrls: ['./app.component.css'] /* STYLE OF THE VIEW */
})
export class AppComponent {

  showThis: boolean = false;
  canDialISD : boolean = true;
  num: number = 555;

  title = 'LTI Bank'; //DATA may be from the DBMS
  payeeName="Suresh";  fund = 10000;  balance = 50000;
  savObj1: SavingsAccount = new SavingsAccount();
  savObj2: SavingsAccount = new SavingsAccount();
  savObj3: SavingsAccount = new SavingsAccount();

  

  savAry: SavingsAccount[] = [
    {accountNumber:1001,accountHolder:"Paresh",accountBalance:30000 },
    {accountNumber:1002,accountHolder:"Ritesh",accountBalance:40000 },
    {accountNumber:1003,accountHolder:"Rutesh",accountBalance:50000 },
    {accountNumber:1004,accountHolder:"Jayesh",accountBalance:60000 },
    {accountNumber:1005,accountHolder:"Rakesh",accountBalance:70000 }
  ]

  constructor() { //constructor of the class
    this.savObj1.accountNumber =1000;
    this.savObj1.accountHolder="Suresh";
    this.savObj1.accountBalance=50000;

    this.savObj2.accountNumber =2000;
    this.savObj2.accountHolder="Dinesh";
    this.savObj2.accountBalance=60000;

    this.savObj3.accountNumber =3000;
    this.savObj3.accountHolder="Rajesh";
    this.savObj3.accountBalance=70000;

  }
  cities: City[] = [
    {cityName : 'Mumbai', cityId:1 },
    {cityName : 'Chennai', cityId:2 },
    {cityName : 'Delhi', cityId:3 },
    {cityName : 'Kolkatta', cityId:4 },
    {cityName : 'Bangalore', cityId:5 },
    {cityName : 'Hyderabad', cityId:6 },
  ]
}
class City
{
  cityName:   string;
  cityId: number;
}

class SavingsAccount
{
  accountNumber: number |undefined; //101
  accountHolder: string |undefined ; //Suresh
  accountBalance: number|undefined; //10000

}