import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Scanner;

import dept.exceptions.DepartmentNotFoundException;
public class DeleteTest {
	public static void main(String[] args) {
		//1. load the driver
		try {  
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver...loaded....");
			
			//2 connect to the DB
			System.out.println("Trying to Connect to the database...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:OSE", "system", "manager");
			//the above connection mode : autocommit is ON
			System.out.println("Connected to the DB "+conn);
			
			Scanner scan = new Scanner(System.in);
			
			System.out.println("Enter department number to delete : ");
			int departmentNumber= scan.nextInt();
			
			PreparedStatement pst = conn.prepareStatement("delete from dept where deptno=?");
			pst.setInt(1, departmentNumber);
			int rows = pst.executeUpdate();
			if(rows!=0) {
				System.out.println("Rows deleted : "+rows);
			}
			else {
				DepartmentNotFoundException e = new DepartmentNotFoundException("Department number does not exists!!!"+departmentNumber);
				throw e;
			}
			pst.close();
			conn.close();
			System.out.println("DB resources closed...");
		} 
		catch(DepartmentNotFoundException e) {
			System.out.println("Problem1: "+e.getMessage());
		}
		catch(SQLIntegrityConstraintViolationException e) {
			System.out.println("Problem2: "+e.getMessage());
			//e.printStackTrace();
		}
		catch (SQLException e) {
			System.out.println("Problem3: "+e.getMessage());
		}
		catch (RuntimeException e) {
			System.out.println("Problem4: "+e.getMessage());
		}
		catch (Exception e) {
			System.out.println("Problem5: "+e.getMessage());
		}
		System.out.println("End of main...");
	}
}
