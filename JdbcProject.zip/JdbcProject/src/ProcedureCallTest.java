
/*  create or replace procedure findCustomer(x IN number, y OUT varchar, z OUT varchar)
    as
    begin
      select name,city into y,z from customer where custid = x;
      exception when
      no_data_found then
            y:=null;
            z:=null;
   end;
*/
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Scanner;

public class ProcedureCallTest {
	public static void main(String[] args) {
		//1. load the driver
		try {  
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver...loaded....");
			
			//2 connect to the DB
			System.out.println("Trying to Connect to the database...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:OSE", "system", "manager");
			System.out.println("Connected to the DB "+conn);
			Scanner scan = new Scanner(System.in);
			
			System.out.println("Enter customer number : ");
			int custNumber = scan.nextInt();
			
			CallableStatement cst = conn.prepareCall("{ call findCustomer(?,?,?) }");
				cst.setInt(1, custNumber); //input 
				cst.registerOutParameter(2, Types.VARCHAR); //output type
				cst.registerOutParameter(3, Types.VARCHAR); //output type
				
			cst.execute();
			System.out.println("Callable statement executed....");
			String custName= cst.getString(2);
			String custCity = cst.getString(3);
			
			System.out.println("Customer Name : "+custName);
			System.out.println("Customer City : "+custCity);
			
			cst.close();
			conn.close();
			System.out.println("DB resources closed...");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
