import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Scanner;

import dept.exceptions.DepartmentNumberAlreadyExistException;


public class InsertTest {
	public static void main(String[] args) {
		//1. load the driver
		try {  
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver...loaded....");
			
			//2 connect to the DB
			System.out.println("Trying to Connect to the database...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:OSE", "system", "manager");
			//the above connection mode : autocommit is ON
			System.out.println("Connected to the DB "+conn);
			
			Scanner scan = new Scanner(System.in);
			
			System.out.println("Enter department number : ");
			int departmentNumber= scan.nextInt();
			
			System.out.println("Enter department name : ");
			String departmentName= scan.next();
			
			System.out.println("Enter department location : ");
			String location = scan.next();
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from dept where deptno="+departmentNumber);
			if(rs.next()) {
				throw new DepartmentNumberAlreadyExistException("This department number already exists!!! "+departmentNumber);
			}
			
			PreparedStatement pst = conn.prepareStatement("insert into dept values(?,?,?)");
			pst.setInt(1, departmentNumber);
			pst.setString(2, departmentName);
			pst.setString(3, location);
			
			/*
			 * PreparedStatement pst1 =
			 * conn.prepareStatement("insert into emp values(?,?,?,.......)");
			 * pst1.setInt(1, departmentNumber); pst1.setString(2, departmentName);
			 * pst1.setString(3, location);
			 * ..
			 * ..
			 * ..
			 * 
			 */
			
			int rows = pst.executeUpdate();
			//int rows = pst1.executeUpdate();
			
			System.out.println("Rows added : "+rows);
			pst.close();
			conn.close();
			System.out.println("DB resources closed...");
		} 
		catch(DepartmentNumberAlreadyExistException e) {
			System.out.println("Problem1: "+e.getMessage());
		}
		catch(SQLIntegrityConstraintViolationException e) {
			System.out.println("Problem2: "+e.getMessage());
			//e.printStackTrace();
		}
		catch (SQLException e) {
			System.out.println("Problem3: "+e.getMessage());
		}
		catch (RuntimeException e) {
			System.out.println("Problem4: "+e.getMessage());
		}
		catch (Exception e) {
			System.out.println("Problem5: "+e.getMessage());
		}
		System.out.println("End of main...");
	}
}
