
/*
  create or replace function findOrderTotal(x IN number) return number
    as
       total_order_cost number;
    begin
	select sum(total) INTO total_order_cost from ord where custid=x;
	return total_order_cost;
     exception when
      no_data_found then
            return -1;
   end;
*/   
   import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Scanner;

public class FunctionCallTest {
	public static void main(String[] args) {
		//1. load the driver
		try {  
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver...loaded....");
			
			//2 connect to the DB
			System.out.println("Trying to Connect to the database...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:OSE", "system", "manager");
			System.out.println("Connected to the DB "+conn);
			Scanner scan = new Scanner(System.in);
			
			System.out.println("Enter customer number : ");
			int custNumber = scan.nextInt();
			
			CallableStatement cst = conn.prepareCall("{ ? = call findOrderTotal(?) }");
				cst.setInt(2, custNumber); //input 
				cst.registerOutParameter(1, Types.FLOAT); //output type
				
			cst.execute();
			System.out.println("Callable statement executed....");
			float totalCost = cst.getFloat(1);
		
			System.out.println("Customer Total Order Cost : "+totalCost);
		
			cst.close();
			conn.close();
			System.out.println("DB resources closed...");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
