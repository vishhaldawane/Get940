import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Scanner;

import dept.exceptions.DepartmentNotFoundException;


public class UpdateTest {
	public static void main(String[] args) {
		//1. load the driver
		try {  
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver...loaded....");
			
			//2 connect to the DB
			System.out.println("Trying to Connect to the database...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:OSE", "system", "manager");
			//the above connection mode : autocommit is ON
			System.out.println("Connected to the DB "+conn);
			
			Scanner scan = new Scanner(System.in);
			
			System.out.println("Enter department number : ");
			int departmentNumber= scan.nextInt();
			
			System.out.println("Enter NEW department name : ");
			String departmentName= scan.next();
			
			System.out.println("Enter NEW department location : ");
			String location = scan.next();
			
			/*
			 * Statement st = conn.createStatement(); ResultSet rs =
			 * st.executeQuery("select * from dept where deptno="+departmentNumber);
			 * if(rs.next()) { throw new
			 * DepartmentNumberAlreadyExistException("This department number already exists!!! "
			 * +departmentNumber); }
			 */
			
			PreparedStatement pst = conn.prepareStatement("update dept set dname=?, loc=? where deptno=?");
			pst.setString(1, departmentName);
			pst.setString(2, location);
			pst.setInt(3, departmentNumber);
			int rows = pst.executeUpdate();
			if(rows!=0) {
				System.out.println("Rows updated : "+rows);
			}
			else {
				DepartmentNotFoundException e = new DepartmentNotFoundException("Department number does not exists!!!"+departmentNumber);
				throw e;
			}
			pst.close();
			conn.close();
			System.out.println("DB resources closed...");
		} 
		catch(DepartmentNotFoundException e) {
			System.out.println("Problem1: "+e.getMessage());
		}
		catch(SQLIntegrityConstraintViolationException e) {
			System.out.println("Problem2: "+e.getMessage());
			//e.printStackTrace();
		}
		catch (SQLException e) {
			System.out.println("Problem3: "+e.getMessage());
		}
		catch (RuntimeException e) {
			System.out.println("Problem4: "+e.getMessage());
		}
		catch (Exception e) {
			System.out.println("Problem5: "+e.getMessage());
		}
		System.out.println("End of main...");
	}
}
