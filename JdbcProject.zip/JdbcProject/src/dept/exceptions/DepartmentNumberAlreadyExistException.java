package dept.exceptions;

public class DepartmentNumberAlreadyExistException extends Exception //extends SQLIntegrityConstraintViolationException
{
	public DepartmentNumberAlreadyExistException(String str) {
		super(str);
	}
}
