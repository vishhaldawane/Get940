package dept.exceptions;

public class DepartmentNotFoundException extends Exception //extends SQLIntegrityConstraintViolationException
{
	public DepartmentNotFoundException(String str) {
		super(str);
	}
}