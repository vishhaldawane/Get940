import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import com.lti.Patient;


public class Solution {
	public static void main(String[] args) throws IOException {
		System.out.println("Begin");
		
		StringBuffer line = new StringBuffer();
		FileReader fileInput = new FileReader("New//data.txt");
		char ch;
		int data = fileInput.read();
		while(data!=-1) {
			ch = (char) data;
			line.append(ch); 
		//	System.out.println("ch "+ch);
			//System.out.println(line);
			data = fileInput.read();
		}
		//System.out.println("line : "+line);
		StringTokenizer lineTokenizer = new StringTokenizer(line.toString(),"\n");
		
		StringBuffer patientRecord = new StringBuffer();
		int lineCount=0;
		int col=1;
		int recordCount=0;
		Map<Integer,Patient> patientMap = new HashMap<Integer,Patient>();
		Patient thePatient = new Patient();
		while(lineTokenizer.hasMoreElements()) {
			
			//System.out.println("record Count : "+recordCount);
			
			String lineToken = (String) lineTokenizer.nextElement();
			System.out.println("line token "+lineToken);
			StringTokenizer fieldTokenizer = new StringTokenizer(lineToken.toString(),":");
			++lineCount;
			
			while(fieldTokenizer.hasMoreElements()) {
				
				String key = (String) fieldTokenizer.nextElement();
				String value = (String) fieldTokenizer.nextElement();
				System.out.println(col+" key->"+key);
				System.out.println(col+" value->"+value);
				
				if(col==1) {
					thePatient.setName(value);
					System.out.println("=>Patient : "+thePatient);
				}
				
				if(col==2) {
					thePatient.setUhid(Long.parseLong(value));
					System.out.println("=>Patient : "+thePatient);
				}
				if(col==3) {
					thePatient.setAge(Integer.parseInt(value));
					System.out.println("=>Patient : "+thePatient);
				}
				if(col==4) {
					thePatient.setSex(value.charAt(0));
					System.out.println("=>Patient : "+thePatient);
				}
				if(col==5) {
					thePatient.setMedicine(value);
					System.out.println("=>Patient : "+thePatient);
				}
				
			}
			++col;
			

			if(col>5) {
				
				col=1;
			}
			
			if(lineCount%5==0) {
				System.out.println("------------"+patientRecord);
				++recordCount;
				patientMap.put(recordCount, thePatient);
				thePatient = new Patient(); //reset the patient
				lineCount=0;
				patientRecord.delete(0, patientRecord.length());
				//System.out.println("String is empty "+patientRecord);
				
			}
	
			
			
		}
		
		System.out.println("End");
		
		//patientMap.forEach()
		Set<Integer> allKeys = patientMap.keySet();
		for(Integer theKey :allKeys) {
			System.out.println("Key "+theKey);
			Patient patient = patientMap.get(theKey);
			System.out.println("Patient : "+patient);
			System.out.println("-------------------");
		}
	}
}
