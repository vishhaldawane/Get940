package com.lti;

public class Patient {
	private String name;
	private long uhid;
	private int age;
	private char sex;
	private String medicine;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getUhid() {
		return uhid;
	}
	public void setUhid(long uhid) {
		this.uhid = uhid;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public char getSex() {
		return sex;
	}
	public void setSex(char sex) {
		this.sex = sex;
	}
	public String getMedicine() {
		return medicine;
	}
	public void setMedicine(String medicine) {
		this.medicine = medicine;
	}
	@Override
	public String toString() {
		return "Patient [name=" + name + ", uhid=" + uhid + ", age=" + age + ", sex=" + sex + ", medicine=" + medicine
				+ "]";
	}
	
}
