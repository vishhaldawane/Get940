package banking;

public class MyCalculator {
	static double product(final double a, final double b) {
		//a = a+1;
		return a * b;
	}
	static double divide(final double n, final double d) {
		//a = a+1;
		if(d!=0)
			return 	n / d;
		else
			throw new ArithmeticException("Cannot divide by zero");
	}
}
