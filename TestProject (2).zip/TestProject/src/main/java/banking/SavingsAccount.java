package banking;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.management.RuntimeErrorException;

public class SavingsAccount {
	private int accountNumber;
	private String accountHolder;
	private double accountBalance;
	private String accountHolderEmail;
	
	
	public SavingsAccount() {
		super();
		System.out.println("SavingsAccount()");
	}

	public SavingsAccount(int accountNumber, String accountHolder, double accountBalance) {
		super();
		System.out.println("SavingsAccount(int,String,double)");
		this.accountNumber = accountNumber;
		this.accountHolder = accountHolder;
		this.accountBalance = accountBalance;
	}

	public SavingsAccount(int accountNumber, String accountHolder, 
			double accountBalance, String accountHolderEmail) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolder = accountHolder;
		this.accountBalance = accountBalance;
		this.accountHolderEmail = accountHolderEmail;
	}
	
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	public String getAccountHolderEmail() {
		return accountHolderEmail;
	}

	public void setAccountHolderEmail(String accountHolderEmail) {
		this.accountHolderEmail = accountHolderEmail;
	}

	@Override
	public String toString() {
		return "SavingsAccount [accountNumber=" + accountNumber + ", accountHolder=" + accountHolder
				+ ", accountBalance=" + accountBalance + ", accountHolderEmail=" + accountHolderEmail + "]";
	}

	public void withdraw(double amountToWithdraw) {
	/*	if(amountToWithdraw < 0) {
			throw new RuntimeException("Amount cannot be negative..");
		}*/
		this.accountBalance = this.accountBalance - amountToWithdraw;
		//this.accountBalance=this.accountBalance-1;
	}
	
	public double getBalance() {
		return accountBalance;
	}
	
	public void deposit(double amountToDeposit) {
		this.accountBalance = this.accountBalance + amountToDeposit;
		//this.accountBalance=this.accountBalance+1;
	}
	
	void selfTransfer(SavingsAccount target, double amount) {
		//if some changes here
		this.accountBalance = this.accountBalance - amount;
		//if some changes here
		target.accountBalance = target.accountBalance + amount;
		//if some changes here
	}
	
	void selfTransfer(CurrentAccount target, double amount) {
		//if some changes here
		this.accountBalance = this.accountBalance - amount;
		//if some changes here
		target.accountBalance = target.accountBalance + amount;
		//if some changes here
	}
	
}
class CurrentAccount { 
	double accountBalance;
}

class FundTransferService // third party service
{
	//@Transactional
	void fundTransferService(SavingsAccount s, SavingsAccount t, double amout) {
		/*System.out.println("Trying to load the driver...");
		DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		System.out.println("Driver...loaded....");
		
		//2 connect to the DB
		System.out.println("Trying to Connect to the database...");
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:OSE", "system", "manager");
		
		//the above connection mode : autocommit is ON
		System.out.println("Connected to the DB "+conn);
		
		
		conn.setAutoCommit(false); // start the transaciton
		//if some changes here
		s.withdraw(amout); // udpate query
		//if some changes here
		t.deposit(amout); // udpate query
		//if some changes here
		conn.commit(); // finish the transaction*/
	}
}
