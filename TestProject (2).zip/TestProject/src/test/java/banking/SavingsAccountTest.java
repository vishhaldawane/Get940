package banking;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

public class SavingsAccountTest {

	
	@BeforeEach
	void loadDB() {
		System.out.println("Connecting to the database");
		//literal code to connect to the db
	}
	
	@AfterEach
	void closeDB() {
		System.out.println("DisConnecting from the database");
		//literal code to connect close the db resources
	}	
		
		@RepeatedTest(value=5)
		void test3() {
			SavingsAccount sa1 = new SavingsAccount(101,"Jack",50000.0f,"jack@gmail.com");
			SavingsAccount sa2 = new SavingsAccount(102,"Jane",50000.0f,"jane@gmail.com");
			SavingsAccount sa3 = new SavingsAccount(103,"John",50000.0f,"john@gmail.com");
			
			assertAll("saAny", 
					()-> assertEquals("Jack",sa1.getAccountHolder()),
					()-> assertEquals("jack@gmail.com",sa1.getAccountHolderEmail()));
			
			System.out.println("Object sa1 test passed");
			
	
			assertAll("saAny", 
					()-> assertEquals("Jane",sa2.getAccountHolder()),
					()-> assertEquals("jane@gmail.com",sa2.getAccountHolderEmail()));
		
			System.out.println("Object sa2 test passed");
			
			
			assertAll("saAny", 
					()-> assertEquals("John",sa3.getAccountHolder()),
					()-> assertEquals("john@gmail.com",sa3.getAccountHolderEmail()));
			System.out.println("Object sa3 test passed");
		}
		
		@Test
		void test2()
		{
			System.out.println("Creating SavingsAccount object...");
			SavingsAccount sa = new SavingsAccount();
			assertNotNull(sa); //not null means some value has to be there
			System.out.println("SavingsAccount created...");
			System.out.println("------------------");
		}
		
		//Bus booking project - 45 test cases 
		
		@Test
		void test1()
		{ //A -> B -> C
			System.out.println("Creating SavingsAccount object...");
			double  currentBalance = 50000;
			SavingsAccount sa = new SavingsAccount(101,"Jack",currentBalance);
		assertNotNull(sa); //not null means some value has to be there
			System.out.println("SavingsAccount created...");
			System.out.println("invoking withdraw ......");
			double amountToWithdraw=-3000;
			sa.withdraw(amountToWithdraw);
			//assertEquals( 47000 , currentBalance-amountToWithdraw);
		assertEquals(currentBalance-amountToWithdraw,sa.getBalance());
			System.out.println("withdraw over......");
			System.out.println("------------------");
		}
		
		@Test
		void transferFundsTest()
		{ //A -> B -> C
			System.out.println("Creating SavingsAccount object...");
			double  sourceBalance = 50000;
			double  targetBalance = 30000;
			SavingsAccount target = new SavingsAccount(102,"Jane",targetBalance);
		assertNotNull(target); //not null means some value has to be there
			System.out.println("Found target SavingsAccount ...");

			SavingsAccount source = new SavingsAccount(101,"Jack",sourceBalance);
		assertNotNull(source); //not null means some value has to be there
			System.out.println("Found source SavingsAccount ...");
			System.out.println("checking transfer amount......");
		
			double transferAmount=3000;
		assertFalse(source.getBalance() < transferAmount, "Insufficient balance at source");	
	
			System.out.println("Withdrawing from source......");
			source.withdraw(transferAmount);
			
		assertEquals(sourceBalance-transferAmount, source.getBalance(),"Withdraw is Not working...");
			System.out.println("Withdrawn from source......");
		
			System.out.println("Depositing to target......");
		
		
			target.deposit(transferAmount);
			
			
		assertEquals(targetBalance+transferAmount,target.getBalance(),"Deposit Not working..");
			System.out.println("Deposited to target......");
			
			System.out.println("!!! Transfer succesfull !!!");
			System.out.println("------------------");
		}
}
