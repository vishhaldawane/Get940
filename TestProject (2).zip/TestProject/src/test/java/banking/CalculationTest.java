package banking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

	//named child of     SavingsAccount
class FixedDeposit extends SavingsAccount 
{
	public void withdraw(double d) { //overriding 
		
	}
}
interface BankAccount  {
	void withdraw();
}
public class CalculationTest {
	// 6 to 7 tables 
	@Test
	void test1() { //TDD
		
		//this is Annonymous child of SavingsAccount
		BankAccount ba = () -> //SavingsAccount$1.class
		{
		
		};
		ba.withdraw();
		
		Throwable t = assertThrows(ArithmeticException.class, 
					()->{ MyCalculator.divide(7,0); /*line2 line3*/ } 
					
			);
		//t.printStackTrace();
		assertEquals("Please supply non-zero value", t.getMessage());
		
		
		//assertEquals(0,MyCalculator.divide(7,0));
		System.out.println("passed3");
		
		FixedDeposit f = new FixedDeposit();
		
		f.withdraw(5000);
		
		assertEquals(12,MyCalculator.product(4, 3));
		System.out.println("passed1");
		
		assertEquals(15,MyCalculator.product(5, 3));
		System.out.println("passed2");
		
	
	
		assertEquals(75,MyCalculator.product(15, 5));
		System.out.println("passed4");
		
		assertEquals(60,MyCalculator.product(20, 3));
		System.out.println("passed5");
	}
}

