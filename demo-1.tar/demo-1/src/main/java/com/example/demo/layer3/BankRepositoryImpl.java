package com.example.demo.layer3;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.BankDetail;

@Repository
public class BankRepositoryImpl extends BaseRepository implements BankRepository {

	
	@Transactional
	public BankDetail selectBank(int accountNumber) {
		
		return getEntityManager().find(BankDetail.class, accountNumber);
	}

	@Transactional
	public void updateBank(BankDetail bd) {
		getEntityManager().merge(bd);

	}

}
