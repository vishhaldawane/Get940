package com.example.demo.layer2;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="customer")
public class Customer {

	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="custid")
	int customerId;
	
	@Column(name="name")
	String customerName;
	
	@Column(name="city")
	String city;
	
	@ManyToOne
	@JoinColumn(name="eno")
	private Employee employee1;

	
	
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(int customerId, String customerName, String city) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.city = city;
	
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@JsonIgnore
	public Employee getEmployee1() {
		return employee1;
	}

	public void setEmployee1(Employee employee) {
		this.employee1 = employee;
	}

	
}
