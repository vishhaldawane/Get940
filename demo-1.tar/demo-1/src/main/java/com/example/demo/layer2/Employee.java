package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="emp")
public class Employee {
	
	@Id
	@GeneratedValue
	@Column(name="empno")
	private int employeeNumber;
	
	@Column(name="ename")
	private String employeeName;
	
	@Column(name="salary")
	private double  employeeSalary;
	
	
	/*@Transient - ignored to persist on the db
	int pinNumber;*/
	
	//@OneToMany
	//List<Customer> customers = new HashSet<Customer>();
	
	public Employee(int employeeNumber, String employeeName, double employeeSalary) {
		super();
		System.out.println("Employee(1,2,3) ctor...");
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}
	
	
	public Employee() {
		super();
		System.out.println("Employee() ctor...");
		// TODO Auto-generated constructor stub
	}


	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
}