package com.example.demo.layer2;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

import net.bytebuddy.agent.builder.AgentBuilder.PoolStrategy.Eager;
/*
 NORMALIZED									   http://localhost:8080
  <--------DATA----------> <-----LOGIC --->     WEB            UI
 1			2		  3		      4			     5				6  U/P
 DBs <--> POJOs <--> REPOs <--> SERVICEs <--> CONTROLLERs <--> ANGULAR(UI pages)
 |			|			 |						|				|  http://localhost:4200
 |			|			 |						|				EmployeeManagment <--Module
 emp    Employee.java	 EmployeeRepo			|				Employee.ts (2)
 empno	  employeeNumber EmployeeRepoImpl		@RequestBody	employeNumber										
 ename    employeeName							|				employeeName
 esal	  employeeSalary					via PostMan			employeeSalary
 											CRUD is working		|
 																|
 											-----------------------------
 											|							|
 								EmployeeService.ts	(3)				Employee[Management]Component (1)
 (6)	HttpClient	myhttp;			|										|ngOnInit
 					---------------------					----------------------------------------
 					|										|			|					|
 			addEmpService(Employee x)		EmployeeComponent.ts EmployeeComponent.html AddEmployeeComponent.css
 												ngOnInit() { call the service (7)
 			getAllEmpsService() (4)						|				 Enter empno : 7839
 			|									addEmp(Employee e) {<--+ Enter ename : KING
 myhttp.post(url+'emps',x);							...some work	   | Enter sal   : 5000 Rs(pipe)
 			|										addEmpService(e);  +--	ADD
 http://localhost:8080(5)								..some work			fetch All
 												}								*ngFor
 			getEmpService() 						getEmps(){}				1234  Jack 5000  Delete Update
 			delEmpService()						delEmp()				2233  Jill 5600  Delete Update
 			updateEmpService()					updateEmp()				6789  Jane 6878  Delete Update
 	Rule Number 1:
 	java pojo's fields must match with angular pojos
 	
 */
@Entity
@Table(name="emp")
public class Employee {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="empno")
	private int employeeNumber;
	
	@Column(name="ename")
	private String employeeName;
	
	@Column(name="salary")
	private double  employeeSalary;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "employee1")
	private Set<Customer> customers = new HashSet<Customer>();
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER, mappedBy = "employee" )
	private Set<BankDetail> bankDetails = new HashSet<BankDetail>();
	
	
	
	public Set<BankDetail> getBankDetails() {
		return bankDetails;
	}


	public void setBankDetails(Set<BankDetail> bankDetails) {
		this.bankDetails = bankDetails;
	}

	public Set<Customer> getCustomers() {
		return customers;
	}


	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}


	public Employee(int employeeNumber, String employeeName, double employeeSalary, Set<BankDetail> bankDetails) {
		super();
		System.out.println("Employee() ctor...layer 2");
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
		this.bankDetails = bankDetails;
	}
	public Employee(int employeeNumber, String employeeName, double employeeSalary) {
		super();
		System.out.println("Employee() ctor...layer 2");
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
		
	}
	
	
	public Employee() {
		super();
		System.out.println("Employee() ctor...");
		// TODO Auto-generated constructor stub
	}


	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
}