package com.example.demo.layer4;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Student;
import com.example.demo.layer2.Student.StudentKey;
import com.example.demo.layer3.StudentRepo;

@Service
public class StudentServiceImpl implements StudentService {

	
	@Autowired
	StudentRepo studRepo;
	
	@Override								//below arguments are passed from the controller
	public void findStudentService(){//int std, String div, int roll) 
		Scanner scan1 = new Scanner(System.in); // in reality u would take it from the controller, and controller from angular
		Scanner scan2 = new Scanner(System.in); 
		Scanner scan3 = new Scanner(System.in); 
		
		System.out.println("Enter std : ");
		int standard = scan1.nextInt();
		
		System.out.println("Enter div : ");
		String divison = scan2.nextLine();
		
		System.out.println("Enter roll : ");
		int rollno = scan3.nextInt();
		
		Student student = studRepo.getStudent(new Student.StudentKey(standard, divison, rollno));
		System.out.println("student : "+student);
		
	}

	@Override
	public void findStudentService(StudentKey key) {
		// TODO Auto-generated method stub
		
	}

	
	public void updateStudentService() { //@PathVariable Or @RequestBody
		// TODO Auto-generated method stub
		Scanner scan1 = new Scanner(System.in); // in reality u would take it from the controller, and controller from angular
		Scanner scan2 = new Scanner(System.in); 
		Scanner scan3 = new Scanner(System.in); 
		Scanner scan4 = new Scanner(System.in); 
		
		System.out.println("Enter std : ");
		int standard = scan1.nextInt();
		
		System.out.println("Enter div : ");
		String divison = scan2.nextLine();
		
		System.out.println("Enter roll : ");
		int rollno = scan3.nextInt();
		
		System.out.println("Enter new name : ");
		String  newName = scan4.nextLine();
		
		Student studentToModify = new Student(new Student.StudentKey(standard,divison,rollno), newName);
		studRepo.updateStudent(studentToModify);
	}

}
