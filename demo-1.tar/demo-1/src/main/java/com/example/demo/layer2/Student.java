package com.example.demo.layer2;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="students")
public class Student {

	@EmbeddedId
	StudentKey studKey;

	String name;
	
	public Student(StudentKey studKey, String name) {
		super();
		this.studKey = studKey;
		this.name = name;
	}




	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}




	@Embeddable
	public static class StudentKey implements Serializable
	{
		int std;
		String div;
		int rollno;
		
		
		public StudentKey() {
			super();
			// TODO Auto-generated constructor stub
		}
		public StudentKey(int std, String div, int rollno) {
			super();
			this.std = std;
			this.div = div;
			this.rollno = rollno;
		}
		
		
		
		
		@Override
		public int hashCode() {
			return Objects.hash(div, rollno, std);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			StudentKey other = (StudentKey) obj;
			return Objects.equals(div, other.div) && rollno == other.rollno && std == other.std;
		}
		public int getStd() {
			return std;
		}
		public void setStd(int std) {
			this.std = std;
		}
		public String getDiv() {
			return div;
		}
		public void setDiv(String div) {
			this.div = div;
		}
		public int getRollno() {
			return rollno;
		}
		public void setRollno(int rollno) {
			this.rollno = rollno;
		}
		@Override
		public String toString() {
			return "StudentKey [std=" + std + ", div=" + div + ", rollno=" + rollno + "]";
		}
	
	}

	@Override
	public String toString() {
		return "Student [studKey=" + studKey + ", name=" + name + "]";
	}




	
	
	
}
