package com.example.demo.layer4;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Student;

@Service
public interface StudentService {
	void findStudentService();//(int std, String div, int roll);
	void findStudentService(Student.StudentKey key);
	void updateStudentService();
}
