package com.example.demo.layer5;

public interface MailService {
	public void employeeRegistration(String registeredUser, String registeredUserEmail);
		
	public void sendMail(String info,String email);
}
