package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="bank")
public class BankDetail {

		@Id
		@GeneratedValue
		int bankid;
			
		@Column(name="bankaccountnumber")
		Integer bankAccountnumber;
		
		@Column(name="bankname")
		String bankname;
		
		@Column(name="balance")
		Integer balance;
		
		
		@ManyToOne
		@JoinColumn(name="eno")
		private Employee employee;


		public int getBankId() {
			return bankid;
		}


		public void setBankId(int bankId) {
			this.bankid = bankId;
		}


		public Integer getBankAccountNumber() {
			return bankAccountnumber;
		}


		public void setBankAccountNumber(Integer bankAccountNumber) {
			this.bankAccountnumber = bankAccountNumber;
		}


		public String getBankName() {
			return bankname;
		}


		public void setBankName(String bankName) {
			this.bankname = bankName;
		}


		public Integer getBalance() {
			return balance;
		}


		public void setBalance(Integer balance) {
			this.balance = balance;
		}


		@JsonIgnore
		public Employee getEmployee() {
			return employee;
		}


		public void setEmployee(Employee employee) {
			this.employee = employee;
		}
		
		
		
		
}
