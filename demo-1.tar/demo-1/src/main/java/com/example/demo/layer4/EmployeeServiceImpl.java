package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Employee;
import com.example.demo.layer2.EmployeeNotFoundException;
import com.example.demo.layer3.EmployeeRepositoryImpl;

@Service //@Component only
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepositoryImpl empRepo;
	
	public List<Employee> selectAllEmployeesService() {
		//business logic goes here if desired...
		System.out.println("EmployeeServiceImpl: Layer 4 ");
		//then talk to the kitchen code written below
		return empRepo.selectAllEmployees();
	}

	@Override
	public Employee selectEmployeeService(int employeeNumber) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteEmployeeService(int empno)  {
		System.out.println("deleteEmployeeService()...method ");
		String message="Employee Not Found";
		
		boolean deleted=false;
		try {
			empRepo.deleteEmployee(empno);//invoke the repo
			deleted= true;
			message = "Employee Deleted";
			System.out.println("SErvice deleted :" );
		} catch (EmployeeNotFoundException e) {
			e.printStackTrace();
		//	message = e.getMessage();
			
		}
		
	}
	
//angular 6 dining--you (coding 5) ---> mother (service 4 ) ---->    maid (repo 3 )-->Bread 2 [ pojo ] Butter 2 -> market layer 1 
}
