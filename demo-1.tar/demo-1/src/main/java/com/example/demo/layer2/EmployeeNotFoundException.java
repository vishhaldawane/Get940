package com.example.demo.layer2;

public class EmployeeNotFoundException extends Exception {
	public EmployeeNotFoundException(String str) {
		super(str);
	}
}
