package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Student;

@Repository
public class StudentRepoImpl extends BaseRepository implements StudentRepo {

	
	@Autowired
	EntityManager entityManager ;
	

	@Transactional
	public Student getStudent(Student.StudentKey sk) {
		Student s = entityManager.find(Student.class, sk);
		return s;
	}
	
	@Transactional
	public List<Student> getAllStudents() {
		List<Student> studentList = entityManager.createQuery(" from Student").getResultList();
		
		return studentList;
	}

	@Transactional
	public void createStudent(Student st) {
		entityManager.persist(st);
		
	}
	
	@Transactional
	 public void updateStudent(Student st) {
		entityManager.merge(st);
	}

}
