create table emp
(
   empno integer primary key,
   ename varchar(20),
   salary integer
)

insert into emp values (101,'jack',1000);
insert into emp values (102,'jane',2000);
insert into emp values (103,'joby',3000);

CRUD WOULD BE EASY

create table customer
(
   custid integer primary key,
   name varchar(20),
   city varchar(20),
   eno integer references emp(empno)
   IMGURL VARCHAR(50); //PICASO IMAGE OF ONLINE MODE - URL/ REMOTE / LOCAL URL
)
insert into customer values (501,'SPORTS SHOP','NY',101);
insert into customer values (502,'KIDS SPORTS','NJ',101);
insert into customer values (503,'WOMEN SPORTS','NP',101);

insert into customer values (504,'Football SHOTP','ND',102);
insert into customer values (505,'HOCKEY SPORTS','NM',102);
insert into customer values (506,'CRICKET SPORTS','NW',102);

insert into customer values (507,'BOXING SHOTP','NS',103);
insert into customer values (508,'BADMINTON SPORTS','NK',103);
insert into customer values (509,'RACKET SPORTS','NB',103);

create table Order
(
   ordid integer primary key,
   ordddate varchar(20),
   discount varchar(20),
   cid integer references customer(custid)
)


