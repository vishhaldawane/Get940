create table emp
(
   empno integer,
   ename varchar(20),
   salary integer
)

insert into emp values (101,'jack',1000);
insert into emp values (102,'jane',2000);
insert into emp values (103,'joby',3000);