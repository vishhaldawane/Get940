package com.example.demo.layer5.dto;

public class EmpCustBankDTO {
	int employeenumber;
	int customerid;
	int bankid;
	
	public EmpCustBankDTO() {
		System.out.println("EmpCustBankDTO() ctor...");
	}
	
	public int getEmployeenumber() {
		return employeenumber;
	}
	public void setEmployeenumber(int employeenumber) {
		this.employeenumber = employeenumber;
	}
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public int getBankid() {
		return bankid;
	}
	public void setBankid(int bankid) {
		this.bankid = bankid;
	}
	
	
}
