package com.example.demo;


import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Student;
import com.example.demo.layer3.StudentRepoImpl;
import com.example.demo.layer4.StudentService;

@SpringBootTest
class Demo1ApplicationTests {

	@Autowired
	StudentRepoImpl stuRepo;
	
	@Autowired
	StudentService stuServ;
	
	
	@Test
	void createOneStudentTest() {
		System.out.println("Creating  a student...");
		Student.StudentKey skey = new Student.StudentKey(13,"C",33);
		Student s = new Student(skey,"JULIE");
		stuRepo.createStudent(s);	
	}
	
	@Test
	void updateOneStudentTest() {
		System.out.println("Loading a student...");
		Student.StudentKey skey = new Student.StudentKey(13,"C",33);
		Student s = stuRepo.getStudent(skey); //attached object with DB
		System.out.println("Current name is : "+s.getName());
		s.setName("JULIA"); //on attached object name is set | set method means update query
		stuRepo.updateStudent(s);	//update query fired,
	}
	
	@Test
	void loadOneStudentTest() {
		System.out.println("Loading a student...");
		Student s = stuRepo.getStudent(new Student.StudentKey(13,"C",33));
		System.out.println("s "+s);
	}
	
	
	@Test
	void loadAllStudentsTest() {
		System.out.println("Loading all the students...");
		List<Student> studentList = stuRepo.getAllStudents();
		System.out.println("studentList "+studentList.size());
		for (Student student : studentList) {
			System.out.println("Student : "+student);
		}
	}
	
	@Test
	void loadOneStudentServiceTest() {
		//stuServ.findStudentService();
	}
	
	@Test
	void updatedOneStudentServiceTest() {
		//stuServ.updateStudentService();
	}
}


