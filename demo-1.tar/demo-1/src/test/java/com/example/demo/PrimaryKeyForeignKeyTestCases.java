package com.example.demo;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.BankDetail;
import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Department;
import com.example.demo.layer2.Employee;
import com.example.demo.layer2.Employee2;
import com.example.demo.layer2.EmployeeNotFoundException;
import com.example.demo.layer2.Student;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.BaseRepository;
import com.example.demo.layer3.CustomerRepository;
import com.example.demo.layer3.EmployeeRepository;
import com.example.demo.layer3.StudentRepoImpl;
import com.example.demo.layer4.StudentService;

@SpringBootTest
class PrimaryKeyForeignKeyTestCases {

	@Autowired
	EmployeeRepository empRepo;
	
	@Autowired
	CustomerRepository custRepo;
	
	@Autowired
	BankRepository bankRepo;
	
	@Autowired
	BaseRepositoryImpl base;
	
	
	@Test
	void addNewEmployeeAlongWithNewBankDetails() {
		
		Employee emp = new Employee(101,"jack",5000);
		
		Set<BankDetail> banks = new HashSet<BankDetail>();
		
		banks.add(new BankDetail(1030,1,"ICICI",3000,emp)); //<---watch emp is set here as FK
		banks.add(new BankDetail(1031,2,"SBI",3300,emp)); // emp as fk
		banks.add(new BankDetail(1032,3,"HDFC",3330,emp)); //emp as fk
		
		emp.setBankDetails(banks); // all bank details are set to emp
		base.saveRecord(emp); //emp is saved... hence all the nested bank is also set in db

	}
	
	@Test
	void addNewEmployeeWithoutBankDetailAndCustomerChildren() {
		Employee newEmp = new Employee();
		newEmp.setEmployeeNumber(102);
		newEmp.setEmployeeName("JANE");
		newEmp.setEmployeeSalary(6000);
		try {
			empRepo.updateEmployee(newEmp);
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test
	void addNewCustomerWithoutParentEmployee() { //new customer added without its parent emp
		Customer newCust = new Customer(555,"Women Sports","Delhi");
		custRepo.updateCustomer(newCust); //for that call merge and not insert
		//the above line has created customer without parent emp's FK in it
		//DONT CALL PERSIST, RATHER CALL MERGE
	}
	
	@Test
	void addNewBankDetailWithoutParentEmployee() {
		BankDetail newBankDetail = new BankDetail(999,1,"ICICI Bank",85000);
		bankRepo.updateBank(newBankDetail);
		
	}
	
	@Test
	void assignExistingBankDetailToExistingEmployee() {
		
		try {
			Employee foundEmp = empRepo.selectEmployee(102);//YET doesnt have bank 
			BankDetail foundBankDetail = bankRepo.selectBank(999); //yet doesnt have emp as fk
			//Set is captured for add(), since emp has One to Many bank details
			foundEmp.getBankDetails().add(foundBankDetail); 
			foundBankDetail.setEmployee(foundEmp); //<--SETTING empno->FK FOR BANK 
			bankRepo.updateBank(foundBankDetail);
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	void assignExistingCustomerToExistingEmployee() {
		
		try {
			Employee foundEmp = empRepo.selectEmployee(102);//YET doesnt have customer
			Customer foundCustomer= custRepo.selectCustomer(555); //yet doesnt have emp as fk
			//Set is captured for add(), since emp has One to Many Customer details
			foundEmp.getCustomers().add(foundCustomer); 
			foundCustomer.setEmployee1(foundEmp); //<--SETTING empno->FK FOR BANK 
			custRepo.updateCustomer(foundCustomer);
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}


