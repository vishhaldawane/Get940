class MyInteger // Container to hold integer
{
	private int x;
	private int y;
	
	MyInteger(int a, int b) {
		x = a;
		y = b;
	}
	
	public void print() //algorithm to print integer
	{
		System.out.println("x : "+x); //print
		System.out.println("y : "+y); //print
	}
	public void swap() { //local x and y - algorithm to swap integer
		System.out.println("Swapping...");
		int temp = x; 
		x = y;//changes are happening on the data member 
		y = temp; //changes are happening on the data member
		System.out.println("Swapped...");
	}
}
class MyFloat // Container to hold float
{
	private float x;
	private float y;
	
	MyFloat(float a, float b) {
		x = a;
		y = b;
	}
	
	public void print()
	{
		System.out.println("x : "+x); //print
		System.out.println("y : "+y); //print
	}
	public void swap() { //local x and y
		System.out.println("Swapping...");
		float temp = x; 
		x = y;//changes are happening on the data member 
		y = temp; //changes are happening on the data member
		System.out.println("Swapped...");
	}

}

class MyString // Container to hold String
{
	private String x;
	private String y;
	
	MyString(String a, String b) {
		x = a;
		y = b;
	}
	
	public void print()
	{
		System.out.println("x : "+x); //print
		System.out.println("y : "+y); //print
	}
	public void swap() { //local x and y
		System.out.println("Swapping...");
		String temp = x; 
		x = y;//changes are happening on the data member 
		y = temp; //changes are happening on the data member
		System.out.println("Swapped...");
	}

}

class MySong // Container to hold Songs
{
	private Song x;
	private Song y;
	
	MySong(Song a, Song b) {
		x = a;
		y = b;
	}
	
	public void print()
	{
		System.out.println("x : "+x); //print
		System.out.println("y : "+y); //print
	}
	public void swap() { //local x and y
		System.out.println("Swapping...");
		Song temp = x; 
		x = y;//changes are happening on the data member 
		y = temp; //changes are happening on the data member
		System.out.println("Swapped...");
	}

}

class Song
{
	private String title;
	private String artist;
	private String album;
	private int year;
	
	Song(String title, String artist, String album, int year) {
		super();
		this.title = title;
		this.artist = artist;
		this.album = album;
		this.year = year;
	}
	@Override
	public String toString() {
		return "Song [title=" + title + ", artist=" + artist + ", album=" + album + ", year=" + year + "]";
	}
	
	
}
             
public class GenericTest2 {
	public static void main(String[] args) {
		MyInteger  mi = new MyInteger(10,20); //10 20 known as mi
		mi.print();
		mi.swap();
		mi.print();
		System.out.println("--------------------");
		MyFloat mf = new MyFloat(10.5f, 90.5f);
		mf.print();
		mf.swap();
		mf.print();
		System.out.println("--------------------");
		MyString ms = new MyString("Julia","Robert");
		ms.print();
		ms.swap();
		ms.print();
		System.out.println("--------------------");
		Song s1 = new Song("My Heart Will Go On", "Celine D", "Titanic", 1996);
		Song s2 = new Song("Zhingat", "Ajay Atul", "Sairat", 2016);
		
		MySong mySongs = new MySong(s1,s2);
		mySongs.print();
		mySongs.swap();
		mySongs.print();
		
		
	}
}
