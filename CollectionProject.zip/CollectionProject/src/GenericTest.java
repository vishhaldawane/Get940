
public class GenericTest {
	public static void print(int x, int y)
	{
		System.out.println("main: x : "+x); //print
		System.out.println("main: y : "+y); //print
	}
	//java neither support call by address nor call by reference
	// java supports call by value
	
	public static void swap(int x, int y) { //local x and y
		System.out.println("Swapping...");
		int temp = x; 
		x = y;//changes are happening on swap's x 
		y = temp; //changes are happening on swap's y
		System.out.println("Swapped...");
	}
	public static void main(String[] args) {
		int x=10; //declare cum initialize
		int y=20; //declare cum initialize
		print(x,y); //10,20
		swap(x,y); //value of main's x,y is copied there on swap's x,y 
		print(x,y); // 10 20
	}
}
