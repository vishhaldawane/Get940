class MyValue<AnyType> //Generic Container to hold Any Type
{
	private AnyType x;	private AnyType y;
	
	MyValue(AnyType a, AnyType b) {		x = a;		y = b;	}
	
	public void print() //algorithm to print integer
	{
		System.out.println("x : "+x); //print
		System.out.println("y : "+y); //print
	}
	public void swap() { //local x and y - algorithm to swap integer
		System.out.println("Swapping...");
		AnyType temp = x;		x = y;		y = temp; 
		System.out.println("Swapped...");
	}
}

             
public class GenericTest3 {
	public static void main(String[] args) {
//MyValue is a raw type. 
//References to generic type MyValue<AnyType> should be parameterized
		
		MyValue<Integer>   mi = new MyValue<Integer>(10,20); //10 20 known as mi
		mi.print();
		mi.swap();
		mi.print();
		System.out.println("--------------------");
		MyValue<Float> mf = new MyValue<Float>(10.5f, 90.5f);
		mf.print();
		mf.swap();
		mf.print();
		System.out.println("--------------------");
		MyValue<String> ms = new MyValue<String>("Julia","Robert");
		ms.print();
		ms.swap();
		ms.print();
		System.out.println("--------------------");
		Song s1 = new Song("My Heart Will Go On", "Celine D", "Titanic", 1996);
		Song s2 = new Song("Zhingat", "Ajay Atul", "Sairat", 2016);
		
		MyValue<Song> mySongs = new MyValue<Song>(s1,s2);
		mySongs.print();
		mySongs.swap();
		mySongs.print();
		
		
	}
}
