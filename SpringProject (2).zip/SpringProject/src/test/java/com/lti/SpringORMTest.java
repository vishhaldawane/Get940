package com.lti;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
@ExtendWith( SpringExtension.class )
@ContextConfiguration(locations="classpath:spring2.xml")
public class SpringORMTest  {
	@Autowired 
	private FlightRepository2  flightRepo;
	@Test
	public void testJPA1() {
		List<Flight> flList = flightRepo.getAvailableFlights();
		for (Flight f : flList) {
			System.out.println("Flight number :  "+f.getFlightNumber());
			System.out.println("Flight name   :  "+f.getFlightName());
			System.out.println("Flight source :  "+f.getFlightSource());
			System.out.println("Flight dest   :  "+f.getFlightDestination());
			System.out.println("--------------------");
		}
	}

}
