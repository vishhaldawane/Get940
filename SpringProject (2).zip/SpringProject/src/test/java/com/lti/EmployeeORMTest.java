/*
 * 		4th generation time table
 * 
 * 					imp				not impt
 *  -------------------------------------------------
 * 	urgent		case study analysis
 * 				un normalized data
 * 				normalized data
 * -------------------------------------------------
 * not urgent		git pull/
 * 				push/collaboration
 * -------------------------------------------------
 * 
 * */
package com.lti;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.lti.layer2.Employee;
import com.lti.layer3.EmployeeRepository;
import com.lti.layer3.exceptions.EmployeeNotFoundException;
@ExtendWith( SpringExtension.class )
@ContextConfiguration(locations="classpath:spring2.xml")
public class EmployeeORMTest  {
	
	@Autowired 
	private EmployeeRepository  employeeRepo;
	
	@Test
	public void insertEmployeeTest() {
		System.out.println("Employee Repo : "+employeeRepo);
		Employee emp = new Employee();
		//primary key generated
		emp.setName("JACK"); //2
		emp.setJob("MANAGER"); //3
		emp.setManagerEmployeeNumber(7839); //4
		
		LocalDate ld = LocalDate.of(2021, 3, 25);
		emp.setHiredate(ld); //5
		
		emp.setSalary(new Float(4500)); //6
		emp.setCommission(new Float(500)); //7
		emp.setDepartmentNumber(10); //8
		
		employeeRepo.insertEmployee(emp);
		
	}
	
	@Test
	public void findEmployeeTest() {
		System.out.println("Employee Repo : "+employeeRepo);
		Employee emp = null;
		try {
			emp = employeeRepo.selectEmployee(7839);
			System.out.println("Emp Name : "+emp.getName());
			System.out.println("Emp Job  : "+emp.getJob());
		}
		catch(EmployeeNotFoundException  e) {
			System.out.println("Employee not found "+e.getMessage());
		}
		
	}

}
