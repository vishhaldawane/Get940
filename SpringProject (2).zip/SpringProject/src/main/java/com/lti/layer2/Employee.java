package com.lti.layer2;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

//EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM     DEPTNO

@Entity
@Table(name="emp")
public class Employee {
	
	@Id
	@GeneratedValue
	@Column(name="EMPNO")
	private int employeeNumber;
	
	@Column(name="ENAME", length=10)
	private String name;
	
	@Column(name="JOB", length=10)
	private String job;
	
	@Column(name="MGR")
	private Integer managerEmployeeNumber;
	
	@Column(name="HIREDATE")
	private LocalDate hiredate;
	
	@Column(name="SAL")
	private Float salary;
	
	@Column(name="COMM")
	private Float commission;
	
	@Column(name="DEPTNO") 
	private Integer departmentNumber;
	
	public Employee() {
		super();
		System.out.println("Employee() constructed...");
	}

	public int getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public Integer getManagerEmployeeNumber() {
		return managerEmployeeNumber;
	}

	public void setManagerEmployeeNumber(Integer managerEmployeeNumber) {
		this.managerEmployeeNumber = managerEmployeeNumber;
	}

	public LocalDate getHiredate() {
		return hiredate;
	}

	public void setHiredate(LocalDate hiredate) {
		this.hiredate = hiredate;
	}

	public Float getSalary() {
		return salary;
	}

	public void setSalary(Float salary) {
		this.salary = salary;
	}

	public Float getCommission() {
		return commission;
	}

	public void setCommission(Float commission) {
		this.commission = commission;
	}
	
}
