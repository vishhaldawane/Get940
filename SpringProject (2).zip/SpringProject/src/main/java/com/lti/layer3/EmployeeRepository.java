package com.lti.layer3;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.layer2.Employee;
import com.lti.layer3.exceptions.EmployeeNotFoundException;

//IF THIS INTERFACE DESIGNED BY THE TEAM LEADER ( WITH GROUP DISCUSSION )
@Repository
public interface EmployeeRepository {
	
	void insertEmployee(Employee ref);
	
	Employee selectEmployee(int employeeNumber) throws EmployeeNotFoundException;
	List<Employee> selectEmployeeByJob(String job) throws EmployeeNotFoundException;
	List<Employee> selectEmployeeByHiredateRange(Date startDate, Date endDate) throws EmployeeNotFoundException;
	List<Employee> selectEmployeeBySalaryRange(float minSalary, float maxSalary) throws EmployeeNotFoundException;
	List<Employee> selectEmployeeByCommision() throws EmployeeNotFoundException;
	List<Employee> selectEmployeeByCommision(int value) throws EmployeeNotFoundException;
	List<Employee> selectEmployeeByDeptno(int deptno) throws EmployeeNotFoundException;

	void updateEmployee(Employee employee) throws EmployeeNotFoundException;
	void deleteEmployee(Employee employee) throws EmployeeNotFoundException;
}









