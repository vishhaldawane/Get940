package com.lti.layer3;

import javax.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public abstract class BaseRepository {
	EntityManagerFactory entityManagerFactory;

	@Autowired
	public void setEntityManagerFactory(EntityManagerFactory factory) {
		System.out.println("BaseRepository: setEntityManagerFactory() invoked..."+factory);
		entityManagerFactory = factory;
	}

	public EntityManagerFactory getEntityManagerFactory() {
		System.out.println("BaseRepository: getting entityManagerFactory");
		return entityManagerFactory;
	}
	
}
