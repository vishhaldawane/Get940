package com.lti.layer3.exceptions;

public class EmployeeNotFoundException extends Exception {
	public EmployeeNotFoundException(String str) {
		super(str);
	}
}
