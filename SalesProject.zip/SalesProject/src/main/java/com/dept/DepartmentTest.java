package com.dept;



import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;
import org.hibernate.service.ServiceRegistry;

public class DepartmentTest {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Department dept1 = new Department();
		dept1.setDepartmentNumber(50);
		dept1.setDepartmentName("QMS");
		dept1.setDepartmentLocation("Mumbai");
		
		System.out.println("deptno : "+dept1.getDepartmentNumber());
		System.out.println("name   : "+dept1.getDepartmentName());
		System.out.println("loc    : "+dept1.getDepartmentLocation());
	
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		System.out.println("=>Service Registry.."+serviceRegistry);
		Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
		System.out.println("=>Meta Data.."+metadata);
		
		SessionFactory factory = metadata.getSessionFactoryBuilder().build();
		System.out.println("=>session factory.."+factory);
		
		Session session = factory.getCurrentSession();
		System.out.println("=>session.."+session);
	
		
		Transaction tx = session.beginTransaction();
		System.out.println("=>transaction.."+tx);
		
		//INSERT
		//session.save(dept1); // insert query is fired here
		
		/* SELECT
		 * Department dept3 = session.get(Department.class, 30);
		System.out.println("deptno : "+dept3.getDepartmentNumber());
		System.out.println("name   : "+dept3.getDepartmentName());
		System.out.println("loc    : "+dept3.getDepartmentLocation());
		*/
		
		//Remove a persistent instance from the datastore. 
		//The argument may "bean instance" associated with 
		//the receiving Session - ATTACHED OBJECT
		
		/*Department dept3 = session.get(Department.class, 50);
		session.delete(dept3);*/
		
		//or a transient instance with an identifier 
		//associated with existing persistent state.
		
		/*Department temp = new Department();// NOT YET SAVED
		temp.setDepartmentNumber(50);
		session.delete(temp);
		*/
		
		//UPDATE - first seek the object
		/*Department dept3 = session.find(Department.class, 50);
		//now the object if found,  IT IS SENSITIVE TO CHANGES 
		//BECAUSE IT IS AN ATTACHED OBJECT WITH ORM AND DB
		System.out.println("deptno : "+dept3.getDepartmentNumber());
		System.out.println("name   : "+dept3.getDepartmentName());
		System.out.println("loc    : "+dept3.getDepartmentLocation());
		System.out.println(">> call the required setter methods ");
		dept3.setDepartmentName("QUALITY");
		dept3.setDepartmentLocation("DELHI");
		session.update(dept3);
		*/
		
		/* UPDATE IT PRESUMING 60 IS PRESENT IN THE DB
		 * Department dept3 = new Department();
		dept3.setDepartmentNumber(60);
		dept3.setDepartmentName("TESTing");
		dept3.setDepartmentLocation("Bangalore");
		session.saveOrUpdate(dept3);
		*/
		
		//C R RA U D
							//select * from dept - SQL
		Query query = session.createQuery("from Department",Department.class); //HQL - hibernate query language
		List<Department> deptList = query.getResultList();
		Iterator<Department> deptIter = deptList.iterator();
		while(deptIter.hasNext()) {
			Department dept = deptIter.next();
			System.out.println("deptno : "+dept.getDepartmentNumber());
			System.out.println("name   : "+dept.getDepartmentName());
			System.out.println("loc    : "+dept.getDepartmentLocation());
			System.out.println("-------------------------");
		}
		//Spring - RestController [ like a server ]
		//@GET("/getAllDept") void getAllRecords() { hibernate coding }
		// http://localhost:8080/MyBank/getAllDept
		// http://localhost:4200 - services ( HttpService
		
		tx.commit();
		
		System.out.println("=>transaction..committed..."+tx);
		
		System.out.println("Closing Session Factory ..");
		factory.close();
		System.out.println("Session Factory is closed..");
		//ClarifiedButter c = new Cow().milkACow().coagulate().churn().boil();
		//c.eatDaily();
		
	}
}
class Cow
{
	Milk milkACow()
	{
		Milk m = new Milk();
		return m;
	}
}
class Milk {
	Curd coagulate() {
		return new Curd();
	}
}
class Curd {
	Butter churn() {
		return new Butter();
	}
}
class Butter {
	ClarifiedButter  boil() {
		return new ClarifiedButter();
	}
}
class ClarifiedButter {
	void eatDaily() {
		System.out.println("Eat daily....");
	}
}
