import java.sql.Date;
import java.util.Calendar;
import java.util.TimeZone;


public class ShowCalendar {
	
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
	
		/*String ary[] = TimeZone.getAvailableIDs();
		for (int j = 0; j < ary.length; j++) {
				System.out.println("ary : "+ary[j]);
		}*/
		Date d = new Date(0, 0, 0);
		
		d.getDate();
		
		//TimeZone tz = TimeZone.getTimeZone();
		Calendar cal = Calendar.getInstance();
		
		System.out.println("Day  :"+cal.get(Calendar.DAY_OF_MONTH));
		System.out.println("Month:"+(cal.get(Calendar.MONTH)+1));
		System.out.println("Year :"+cal.get(Calendar.YEAR));
		System.out.println("Hour :"+cal.get(Calendar.HOUR_OF_DAY));
		System.out.println("Mnt  :"+cal.get(Calendar.MINUTE));
		System.out.println("Sec  :"+cal.get(Calendar.SECOND));
		
		
	}
}
