public class DivideTest {

	public static void main(String[] args) {

		System.out.println("Start...");

		try
		{
			String str3 = "10a";
			int num = Integer.parseInt(str3);
			System.out.println("num is "+num);
		}
		catch(NumberFormatException e) {
			System.out.println("Format of number is invalid...");
		}
		
		
		try {
			int ary[] = { 10, 20, 30 };
			System.out.println("ary " + ary[22]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Problem in accessing array...");
		}

		try {
			int x = 10;
			System.out.println("x is : " + x);
			int y = 0;
			System.out.println("y is : " + y);
			int z = 10 / y;
			System.out.println("Division is : " + z);
		} catch (ArithmeticException e) {
			System.out.println("Problem during division...");
		}

		try {
			String str = null;
			System.out.println("str " + str.toUpperCase());
		} catch (NullPointerException e) {
			System.out.println("String is null");

		}
		
		

		try
		{
			String str1 = "john";
			System.out.println("str1 5th character is : "+str1.charAt(5));
		}
		catch(StringIndexOutOfBoundsException e) {
			System.out.println("String index is out of range");
		}
		System.out.println("Finish...");
	}

}
