public class DogTest1 {
	public static void main(String[] args) throws NegativeDogAgeException, DogAgeExceededException {
		
			System.out.println("Start....");
			
			Dog d1 = new Dog("Timu",5);
			d1.show();
			
			Dog d2 = new Dog("Bruno",-7);
			d2.show();
			
			Dog d3 = new Dog("Tommy",3);
			d3.show();
			
			Dog d4 = new Dog("Bravo",8);
			d4.show();
			
			Dog d5 = new Dog("Jimi",9);
			d5.show();
			
			System.out.println("Finish....");

	}

}
