class NegativeDogAgeException extends Exception
{

	NegativeDogAgeException(String str) {
		super(str);
	}
}

class DogAgeExceededException extends Exception
{

	DogAgeExceededException(String string) {
		super(string);
	}
	
}

class Dog
{
	String name;
	int age;
	
	public Dog(String name, int age) throws NegativeDogAgeException, DogAgeExceededException {
		
		this.name = name;
		
		if(age<0) {
			NegativeDogAgeException rte = new NegativeDogAgeException("Age of Dog cannot be negative");
			throw rte;
			//System.out.println("Dog's age cannot be negative...");
		}
		else
			if(age>15) {
				DogAgeExceededException rte = new DogAgeExceededException("Dog's age cannot be more than 14");
				throw rte;
				//System.out.println("Dogs age cannot exceed 14");
			}
			else
				this.age = age;
	}
	
	void show() {
		System.out.println(name+"'s age is "+age);
	}
	
	
}
public class DogTest {
	public static void main(String[] args) {
		
			System.out.println("Start....");
			
				try {
					Dog d1 = new Dog("Tommy",19);
					d1.show();	
				} catch (NegativeDogAgeException e) {
					System.out.println("Problem : "+e.getMessage());
				} catch (DogAgeExceededException e) {
					System.out.println("Problem : "+e.getMessage());
				}
				
				try {
					Dog d2 = new Dog("Sheru",-9);
					d2.show();
				} catch (NegativeDogAgeException | DogAgeExceededException e) {
					System.out.println("Problem : "+e.getMessage());				}
				
				try {
					Dog d3 = new Dog("Bruno",55);
					d3.show();
				} catch (NegativeDogAgeException | DogAgeExceededException e) {
					System.out.println("Problem : "+e.getMessage());
				}
				
			
			System.out.println("Finish....");

	}

}
