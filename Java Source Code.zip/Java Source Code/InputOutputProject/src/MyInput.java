import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/*
class PrintStream {
    println() { }
}

class System
{
	static InputStream in;
	static PrintStream out;
	
}*/
public class MyInput {

	public static void main(String[] args) {
		//10
		//10.2
		//"john"
		//10.2f
		
		// bridge between byte based and character based steram
		// it is used to convert by based data
		// into java type data, e.g. 10 into integer 10
		// eg. "john" into String
		
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader buff = new BufferedReader(isr);
		
		try {
			System.out.println("Enter any number : ");
			String name= buff.readLine();
			int x = Integer.parseInt(name);
			System.out.println("Entered num : "+x);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		System.out.println("Enter any number : ");
		Scanner s = new Scanner(System.in);
		int i = s.nextInt();
		System.out.println("Entered number is "+i);
		
	}

}









