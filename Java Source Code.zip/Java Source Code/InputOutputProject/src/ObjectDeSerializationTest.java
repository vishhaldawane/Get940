import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


public class ObjectDeSerializationTest {

	public static void main(String[] args) {
		
		try {
			
			Account a = null;
			System.out.println("Object reference created....");
			
						
			FileInputStream fin = new FileInputStream("acc.ser");
			System.out.println("File ready to read..");;
			
			ObjectInputStream ooi = new ObjectInputStream(fin);
			System.out.println("Object Inputstream created....");
	
			a = (Account) ooi.readObject();
			System.out.println("Object read or DE-SERIALIZED......");
			a.showAccount();
			
			ooi.close();
			fin.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		


	}

}
