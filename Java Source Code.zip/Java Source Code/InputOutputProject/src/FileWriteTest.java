import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


class MyFrame extends JFrame implements ActionListener
{
	JTextField name = new JTextField(20);
	JTextArea jt = new JTextArea(15,15);
	JButton sav = new JButton("SAVE FILE");
	JScrollPane jsp = new JScrollPane(jt, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	
	
	public void actionPerformed(ActionEvent arg0) {
		System.out.println("Button is clicked...");
		try {
			FileOutputStream fout = new FileOutputStream(name.getText());
			String str = jt.getText();
			byte b[] = str.getBytes();
			fout.write(b);
			fout.close();
			
			JOptionPane.showMessageDialog(this,"File is saved");
			
			
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(this,e.getMessage());
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this,e.getMessage());
		}
		
	}
	
	MyFrame() {
		FlowLayout fl = new FlowLayout();
		Container con = getContentPane();
		
		sav.addActionListener(this);
		
		setLayout(fl);
		
		con.add(name);
		con.add(sav);
		con.add(jsp);
		
		setSize(500,500);
		setLocation(200, 200);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	
}

public class FileWriteTest {

	public static void main(String[] args) {
		MyFrame mfr = new MyFrame();
		mfr.setVisible(true);
	}

}
