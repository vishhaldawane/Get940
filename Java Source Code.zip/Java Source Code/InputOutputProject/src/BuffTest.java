import java.io.*;
import java.util.*;

public class  BuffTest
{
	public static void main(String[] args)
	{
		if (args.length!=1)
		{
			System.out.println("USAGE : BuffTest <filename>");
			System.exit(1);
		}
		String fname = args[0];

		try
		{
			FileInputStream fin1 = new FileInputStream(fname);
			FileInputStream fin2 = new FileInputStream(fname);

			BufferedInputStream buff = new BufferedInputStream(fin2);

			byte b = 0;
			Date then = new Date();
			b = (byte) fin1.read();
			while(b!=-1)
			{
				b = (byte) fin1.read();
			}
			Date now = new Date();

			System.out.println("File read un-buffered in :"+( now.getTime()-then.getTime() ) +" ms");

			b = 0;
			then = new Date();
			b = (byte) buff.read();
			while(b!=-1)
			{
				b = (byte) buff.read();
			}
			now = new Date();

			System.out.println("File read buffered in :"+( now.getTime()-then.getTime() ) +" ms");

			buff.close();
			fin1.close();
			fin2.close();
		}
		catch (FileNotFoundException e)
		{
			System.out.println("Unable to open file");
		}
		catch(IOException e)
		{
			System.out.println("Error in IO is : "+e);
		}
	}
}

