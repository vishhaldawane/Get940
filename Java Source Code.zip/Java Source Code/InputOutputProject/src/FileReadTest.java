import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


class MyFileReader
{
	FileReader fin;
	
	MyFileReader(String filename) {
		 try {
			fin = new FileReader(filename);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void show() {
		try {
			int b = fin.read();
			
			while(b!=-1) {
				System.out.print((char)b);
				b = fin.read();
				Thread.sleep(10);
			}
			System.out.println("\n-------------------");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void closeFile() {
		try {
			fin.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

public class FileReadTest {
	
	public static void main(String[] args) {
		
		MyFileReader mfr1 = new MyFileReader("abc.txt");
		mfr1.show();
		mfr1.closeFile();
		
		MyFileReader mfr2 = new MyFileReader("pqr.txt");
		mfr2.show();
		mfr2.closeFile();
		
		MyFileReader mfr3 = new MyFileReader("xyz.txt");
		mfr3.show();
		mfr3.closeFile();
	
	}

}
