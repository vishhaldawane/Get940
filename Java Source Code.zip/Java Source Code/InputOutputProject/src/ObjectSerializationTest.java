import java.io.Externalizable;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Account implements Serializable//, Externalizable
{
	private int acno;
	private String name;
	private double balance;
	transient int pin; // non-serializable type
	
	Account(int acno, String name, double balance, int p)
	{
		pin = p;
		System.out.println("Account(int,String,double)...");
		if(acno<0)
			System.out.println("Negative account number...");
		else
			this.acno = acno;
		
		char ch; 	boolean found = false;
		
		for(int i=0;i<name.length();i++) {
			ch = name.charAt(i);
			if( (ch>=65 && ch<=90) || (ch>=97 && ch<=122) )
				found=true;
			else { 	
				found=false; 	
				break; 
			}
		}
		if(found==false)
			System.out.println("Invalid String...");
		else
			this.name = name;
		
		if(balance < 0 ) 
			System.out.println("Negative balance .....");
		else
			if(balance <1000) 
				System.out.println("Minimum balance not maintained.....");
			else
				this.balance = balance;
	}
	
	Account(int x)
	{
		this(x,"",0,0); // invoke ctor of the same class
		System.out.println("Account(int)...");
		
	}
	
	Account(String y)
	{
		this(0,y,0,0);
		System.out.println("Account(String)...");
		
	}

	void initialize(int x, String y, double z)
	{
		acno = x;
		name = y;
		balance = z;
	}
	void showAccount()
	{
		System.out.println("Acno : "+acno);
		System.out.println("Name : "+name);
		System.out.println("AcBal: "+balance);
		System.out.println("AcPin: "+pin);
		System.out.println("-------------------------");

	}
	void withdraw(float amt)
	{
	  System.out.println("Withdrawing......"+amt);
	  balance = balance - amt;
	}
	void deposit(float amt)
	{
	  System.out.println("Depositing......"+amt);
	  balance = balance + amt;
	}

	/*@Override
	public void readExternal(ObjectInput arg0) throws IOException,
			ClassNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void writeExternal(ObjectOutput arg0) throws IOException {
		// TODO Auto-generated method stub
		
	}*/
}

public class ObjectSerializationTest {

	public static void main(String[] args) {
		
		try {
			
			Account a = new Account(101,"Suresh",500000,1234);
			System.out.println("Object created....");
			a.showAccount();
			System.out.println("Object shown....");
			
			FileOutputStream fout = new FileOutputStream("acc.ser");
			System.out.println("File created....");
			
			ObjectOutputStream oos = new ObjectOutputStream(fout);
			System.out.println("Object outputstream created....");
	
			oos.writeObject(a);
			System.out.println("Object Written or SERIALIZED......");
			
			oos.close();
			fout.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		


	}

}
