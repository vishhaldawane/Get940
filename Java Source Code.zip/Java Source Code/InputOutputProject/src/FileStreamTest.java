import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


class MyFileStream
{
	FileInputStream fin;
	
	MyFileStream(String filename) {
		 try {
			fin = new FileInputStream(filename);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void show() {
		try {
			byte b = (byte) fin.read();
			
			while(b!=-1) {
				System.out.print((char)b);
				b = (byte) fin.read();
				Thread.sleep(10);
			}
			System.out.println("\n-------------------");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void closeFile() {
		try {
			fin.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
public class FileStreamTest {
	
	public static void main(String[] args) {
		
		MyFileStream mfr1 = new MyFileStream("abc.txt");
		mfr1.show();
		mfr1.closeFile();
		
		MyFileStream mfr2 = new MyFileStream("pqr.txt");
		mfr2.show();
		mfr2.closeFile();
		
		MyFileStream mfr3 = new MyFileStream("xyz.txt");
		mfr3.show();
		mfr3.closeFile();
	
	}

}
