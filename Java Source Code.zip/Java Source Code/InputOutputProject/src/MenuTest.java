import java.io.Console;
import java.util.Scanner;

class Menu
{
	static String menuItem[]={"Add Flight","Show Flight","Modify Flight","Delete Flight"};
	
	static void show() {
		for (int i = 0; i < menuItem.length; i++) {
			System.out.println(i+1+"."+menuItem[i]);	
		}
	}
}

public class MenuTest {
	public static void main(String[] args) {
		int choice=0;
		Scanner s = new Scanner(System.in);
		do
		{
			Menu.show();


			System.out.print("\nEnter choice : ");
			
			choice = s.nextInt();
			
			
				switch(choice)
				{
					case 1: System.out.println("Add    flight invoked...");break;
					case 2: System.out.println("Show   flight invoked...");break;
					case 3: System.out.println("Modify flight invoked...");break;
					case 4: System.out.println("Delete flight invoked...");break;
					case 5: System.out.println("Exiting....");break;
					default: System.out.println("Invalid choice...");
				}
			
		}
		while(choice!=5);
		s.close();
		System.out.println("End of main....");
	}
	

}
