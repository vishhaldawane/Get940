public class CommercialFlightFactory {
	static CommercialFlight getInstance() {
		return new CommercialFlight();
	}
}
