public class Aviation {
	static void security(Flight x) {
		System.out.println("Aviation security started...");
		x.check();
		// x.checkTickets();
		System.out.println("Aviation security stopped...");
		System.out.println("----------------------");
	}

	static void show(Flight x) {
		if (x instanceof CommercialFlight) {
			CommercialFlight cf = (CommercialFlight) x;
			cf.check();
			cf.checkTickets();
		} else if (x instanceof FighterFlight) {
			FighterFlight ff = (FighterFlight) x;
			ff.check();
			ff.checkMissiles();
		} else if (x instanceof CargoFlight) {
			CargoFlight cargo = (CargoFlight) x;
			cargo.check();
			cargo.checkCapacity();
		}
	}
}
