
class FlightWorkshop // producesA relationShip
{
	static Flight getFlight(String hint) {
		Flight f = null;
		if (hint.equals("comm")) {
			f = new CommercialFlight();
		} else if (hint.equals("fight")) {
			f = new FighterFlight();
		} else if (hint.equals("cargo")) {
			f = new CargoFlight();
		} else {
			System.out.println("Invalid hint : " + hint);
		}
		return f;
	}

}