import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class FlightTest {
	public static void main(String[] args) throws IOException {

		System.out.println("---- Flight---");
		System.out.println("1. create Commercial flight");
		System.out.println("2. create fighter    flight");
		System.out.println("3. create cargo      flight");
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader buff = new BufferedReader(isr);

		System.out.println("Give some hint : ");
		String hint = buff.readLine();

		Flight x = FlightWorkshop.getFlight(hint);
		Aviation.show(x);

		/*
		 * if (hint.startsWith("comm")) { CommercialFlight cf = new
		 * CommercialFlight(); cf.check(); cf.checkTickets(); } else if
		 * (hint.startsWith("fight")) { FighterFlight ff = new FighterFlight();
		 * ff.check(); ff.checkMissiles(); } else if (hint.startsWith("cargo"))
		 * { CargoFlight cargo = new CargoFlight(); cargo.check();
		 * cargo.checkCapacity(); }
		 */
		System.out.println("End");

		/*
		 * CommercialFlight x = CommercialFlightFactory.getInstance();
		 * x.check();
		 * 
		 * Flight f = FlightWorkshop.getFlight("pop"); f.check();
		 */

		/*
		 * Flight x = FlightWorkshop.getFlight("cargo"); x.check();
		 */
		/*
		 * Aviation.security(new CommercialFlight()); Aviation.security(new
		 * FighterFlight()); Aviation.security(new CargoFlight());
		 */
		/*
		 * Flight f;// = new Flight(); f = new CommercialFlight(); f.check();
		 * f.checkTickets(); f.checkCapacity(); f.fireMissile();
		 * 
		 * f = new FighterFlight(); f.check(); f.checkTickets();
		 * f.checkCapacity(); f.fireMissile();
		 * 
		 * f = new CargoFlight(); f.check(); f.checkTickets();
		 * f.checkCapacity(); f.fireMissile();
		 */
	}
}
