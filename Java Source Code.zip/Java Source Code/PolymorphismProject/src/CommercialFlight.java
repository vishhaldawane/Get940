/**
 * 
 * This is the direct child of Flight
 * it offers the ticket cost
 *
 */

public class CommercialFlight extends Flight implements Airport {
	public void check() {

		System.out.println("Checking commercial flight..");

	}

	/**
	 * a special implementation of checkTickets...
	 */
	public void checkTickets() {
		System.out.println("Checking tickets...");
	}
}