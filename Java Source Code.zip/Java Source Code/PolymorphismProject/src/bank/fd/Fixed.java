package bank.fd;

/**
 Account class for All types of Accounts
*/
public class Fixed
{
}