package bank;

/**
 Account class for All types of Accounts
*/
public class Account
{
}