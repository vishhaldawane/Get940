package bank.sav;

/**
 Account class for All types of Accounts
*/
public class Savings
{
}