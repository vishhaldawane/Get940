package bank.cur;

/**
 Account class for All types of Accounts
*/
public class Current
{
}