/**
 * 
 * Flight class is the base class for flight hierarchy
 *
 */
public class Flight {
	
	/**
	 * this is a common function for all the flights
	 */
	public void takeoff() {
		System.out.println("Flight takeoff");
	}

	/**
	 * this is a common land() function for all the flights
	 */
	public void land() {
		System.out.println("Flight landing...");
	}

	
	/**
	 * this is a common check function for all the flights
	 */
	public void check() {
		System.out.println("Checking flight...");
	}
}