/**
 * 
 * This interface mandates all commercial flights
 * to develop the checkTickets();
 *
 */
public interface Airport {
	void checkTickets();
}
