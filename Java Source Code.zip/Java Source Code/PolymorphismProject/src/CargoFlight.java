/**
 * 
 * This is the direct child of Flight
 * it offers the carriage capacity
 *
 */
class CargoFlight extends Flight implements CargoBase {
	public void check() {

		System.out.println("Checking Cargo flight..");

	}

	/**
	 * implemented by CargoBase
	 */
	public void checkCapacity() {
		System.out.println("Checking carriage capacity...");
	}
}