/**
 * 
 * This is the direct child of Flight
 * it offer the missiles
 *
 */
public class FighterFlight extends Flight {
	public void check() {

		System.out.println("Checking Fighter flight..");

	}

	void fireMissile() {
		System.out.println("Firing missiles....");
	}

	public void checkMissiles() {
		System.out.println("Checking...missiles..");

	}
}