/**
 * 
 * This is implemented by CargoFlights
 * 
 *
 */
public interface CargoBase {
	void checkCapacity();
}
