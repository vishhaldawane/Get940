
class House
{
	void relax() {
		System.out.println("relaxing at home..");
	}
}

class ClarifiedButter
{
	void ghee() {
		System.out.println("finally got the desi ghee...");
	}
}

class Butter
{
	ClarifiedButter boil() {
		return new ClarifiedButter();
	}
	
}
class Curd
{
	Butter blend()
	{
		return new Butter();
	}
}
class Milk
{
	Curd coagulate() {
		return new Curd();
	}
}
class Cow
{
	Milk getMilk()
	{
		System.out.println("Get milk of Cow..");
		return new Milk();
	}
}
class FarmHouse extends House
{
	Cow c = new Cow();
	
	void relax() {
		System.out.println("relaxing at Farm home..");
	}
	
	void work() {
		System.out.println("Working at Farm House");
		/*Milk m = c.getMilk();
		Curd c = m.coagulate();
		Butter b = c.blend();
		ClarifiedButter cb = b.boil();
		cb.ghee();
*/	
		c.getMilk().coagulate().blend().boil().ghee();
	}

}
public class MethodChaining {
	public static void main(String[] args) {
		/*FarmHouse fh = new FarmHouse();
		fh.relax();
		fh.work();
*/		
		String str="oracle financials";
		
		System.out.println("result:"+str.toUpperCase().substring(7).charAt(3));
		
/*		String str1 = str.toUpperCase();
		
		String str2 = str1.substring(7);
		
		System.out.println("result "+str2);
*/		
		
	}
}
