class Employee
{
	int empno;
	String name;
	double basic;
	int joiningYear;
	public Employee(int empno, String name, double basic, int joiningYear) {
		super();
		this.empno = empno;
		this.name = name;
		this.basic = basic;
		this.joiningYear = joiningYear;
	}
	public String toString() { 
		return name+" empno is "+empno+" joined in "+joiningYear+" has salary "+basic;
	}
	
	public boolean equals(Object arg0) {
		
		boolean isSenior=false;
		
		Employee x = (Employee) arg0;
		
		if(joiningYear < x.joiningYear )
			isSenior=true;
		
		return isSenior;
		
	}
}


public class ObjectTest {
	public static void main(String[] args) {
		Employee e1 = new Employee(101, "Suresh", 5000, 1991);
		Employee e2 = new Employee(101, "Suresh", 5000, 1998);
		
		Employee e3 = new Employee(103, "Ramesh", 5800, 1995);
		Employee e4 = new Employee(104, "Ritesh", 5900, 1994);
		
		int i=100;
		System.out.println("i  is "+i);
		
		System.out.println("e1 is "+e1);
		System.out.println("e2 is "+e2);
		System.out.println("e3 is "+e3);
		System.out.println("e4 is "+e4);
		
		if(e1==e2) // reference value checking
			System.out.println("Both e1 and e2 are equal");
		else 
			System.out.println("Both e1 and e2 are NOT equal");
		
		
		e1 = e3;
		if(e1==e3) // reference value checking
			System.out.println("Both e1 and e3 are equal");
		else 
			System.out.println("Both e1 and e3 are NOT equal");
		
		
		if(e1.equals(e4)) 
			System.out.println("e1 is senior to e4");
		else
			System.out.println("e1 junior to e4");
	}
}
