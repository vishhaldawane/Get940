abstract class MusicalInstrument
{
	abstract void play();
}

class Guitar extends MusicalInstrument
{
	void play() {
		System.out.println("Playing Guitar....");
	}
}

class Violin extends MusicalInstrument
{
	void play() {
		System.out.println("Playing Violin....");
	}
}


abstract class MedicalInstrument
{
	abstract void operate();
}

class Niddle extends MedicalInstrument
{
	void operate() {
		System.out.println("Operating Niddle....");
	}
}

class Cutter extends MedicalInstrument
{
	void operate() {
		System.out.println("Operating Cutter....");
	}
}

class Orchestra
{
	static void startShow(MusicalInstrument x)
	{
		
		x.play();
	}
}

class Hospital
{
	static void operationTheatre(MedicalInstrument x) {
		x.operate();
	}
}

public class AbstractTest1 {
	public static void main(String[] args) {
		
		Guitar g = new Guitar();
		Violin v = new Violin();
		
		System.out.println("Orchestra started...");
		Orchestra.startShow(g);
		Orchestra.startShow(v);
		
		System.out.println("-----------------------");
		
		Niddle n = new Niddle();
		Cutter c = new Cutter();
		
		System.out.println("Operation started...");
		Hospital.operationTheatre(n);
		Hospital.operationTheatre(c);
		
		
	}

}
