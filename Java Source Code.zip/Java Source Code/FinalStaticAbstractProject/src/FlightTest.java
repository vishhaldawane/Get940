interface Airport
{
	void checkTickets(); //by default public abstract
}

interface Airbase
{
	void armMissiles(); //by default public abstract
}

interface CargoBase
{
	void checkCapacity(); //by default public abstract
}


abstract class Flight {
	abstract void takeoff();
	abstract void land();
}

class CommercialFlight extends Flight implements Airport {

	public void checkTickets() {
		System.out.println("Checking tickets...");
	}

	void takeoff() {
		System.out.println("CommercialFlight takeoff...");
	}

	void land() {
		System.out.println("CommercialFlight land.....");
	}
}

class FighterFlight extends Flight implements Airbase {


	public void armMissiles() {
		System.out.println("Missiles armed.......");		
	}

	void takeoff() {
		System.out.println("FighterFlight takeoff.....");

	}

	void land() {
		System.out.println("FighterFlight land.....");
	}

}

class CargoFlight extends Flight implements CargoBase {

	public void checkCapacity() {
		System.out.println("Checking carriaga capacity......");
	}


	void takeoff() {
		System.out.println("CargoFlight takeoff.....");
	}


	void land() {
		System.out.println("CargoFlight land.....");
	}
}

public class FlightTest {
	public static void main(String[] args)   {
		CommercialFlight cf = new CommercialFlight();
		cf.checkTickets();
		cf.takeoff();
		cf.land();
		
		System.out.println("-----------------");
		FighterFlight ff = new FighterFlight();
		ff.armMissiles();
		ff.takeoff();
		ff.land();
		
		System.out.println("-----------------");
		CargoFlight cargo= new CargoFlight();
		cargo.checkCapacity();
		cargo.takeoff();
		cargo.land();
		
	}
}
