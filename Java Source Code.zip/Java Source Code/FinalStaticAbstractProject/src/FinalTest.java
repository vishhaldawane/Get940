


class Chess
{
	final int TOTAL=32;
	
	final void movePawn() {
		String str="1 step ahead \n if its first time then 2 step\n if to kill, then diagonal 1 step ahead";
		System.out.println("Pawn Action :"+str);
	}
}

class GraphicalChess extends Chess
{
	/*void movePawn() {
		String str="10 step ahead if its first time\n, then 10 step diagonal if to kill\n, then any direction, any steps";
		System.out.println("Pawn Action :"+str);
	}*/
	
}
public class FinalTest {

	public static void main(String[] args) {

		GraphicalChess gf = new GraphicalChess();
		gf.movePawn();
		/*final float PI;
		
		PI=3.14f;
		
		System.out.println("PI "+PI);
		
		PI=4.14f;
		
		System.out.println("PI "+PI);
*/		

	}

}
