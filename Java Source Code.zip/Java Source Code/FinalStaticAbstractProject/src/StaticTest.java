class Player
{
	private String name;
	private int score;
	
	private static int count;
	
	static void showTotalCount()
	{
		System.out.println("Total players : "+Player.count);
	}
	
	Player(String name, int score) {
		this.name =name;
		this.score = score;
		++count;
	}
	void showPlayer() {
		System.out.println("Player name  :"+name);
		System.out.println("Player score :"+score);
		System.out.println("----------------");
	}
}

public class StaticTest {
	
	public static void play() {
		System.out.println("-----start of play----");
		Player p4 = new Player("Pollard",6000);
		Player p5 = new Player("Ricky",8000);
		Player.showTotalCount();
		System.out.println("-----end of play----");
		
	}
	
	public static void main(String[] args) {
		System.out.println("-----start of main----");
		Player.showTotalCount();
		
		
		Player p1 = new Player("Sachin",12500);
		Player p2 = new Player("Yuvraj",6500);
		Player p3 = new Player("Sehvag",8500);
		
		
		p1.showPlayer();
		p2.showPlayer();
		p3.showPlayer();
		
		Player.showTotalCount();
		
		play();
		
		System.out.println("-----end of main----");
	}

}
