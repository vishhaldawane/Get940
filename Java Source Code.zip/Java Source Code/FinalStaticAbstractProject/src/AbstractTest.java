/*			GeometricalShape
				|
	----------------------------------------------------------------------
	|		|			|			|			|
	Circle	Rectangle	Triangle	Square		Ellipse
*/
abstract class GeometricalShape
{
	abstract void draw();
	abstract void calcArea();
}

class Circle extends GeometricalShape
{
	int radius;
	static final float PI=3.14f; 
	
	public Circle(int radius) {
		super();
		this.radius = radius;
	}
	void draw() {
		System.out.println("Circle..is drawn....");
	}
	void calcArea() {
		float area = PI * radius * radius;
		System.out.println("Area of Circle is : "+area);
		
	}
}

public class AbstractTest {

	public static void main(String[] args) {
			GeometricalShape gs ;
			
			Circle c = new Circle(40);
			c.draw();
			c.calcArea();
	}

}
