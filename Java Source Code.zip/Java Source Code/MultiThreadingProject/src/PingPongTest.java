class MyThread extends Thread //1
{
	String msg;
	
	public MyThread(String str) {
		// TODO Auto-generated constructor stub
		
		msg = str;
	}

	@Override
	public void run() { // 2
		for (int i = 0; i < 10; i++) {
			System.out.print(msg);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
class MyFrame implements Runnable
{
	String msg;
	public MyFrame(String str) {
		msg = str;
	}
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.print(msg);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
			}
		}
	}
}
public class PingPongTest {
	public static void main(String[] args) {
		/*MyFrame mfr1 = new MyFrame("Ping");
		Thread t1 = new Thread(mfr1);
		MyFrame mfr2 = new MyFrame("Pong");
		Thread t2 = new Thread(mfr2);
		
		t1.start();
		t2.start();*/
		
		Thread t = Thread.currentThread();
		System.out.println("is t alive ? "+t.isAlive());
		System.out.println("t's name   ? "+t.getName());
		
		//3
		System.out.println("Begin main");
		MyThread m1 = new MyThread("Ping");
		System.out.println("Is m1 alive ? "+m1.isAlive());
		System.out.println("m1's name   ? "+m1.getName());
		
		m1.start(); //4
		System.out.println("Is m1 alive ? "+m1.isAlive());
		
		MyThread m2 = new MyThread("Pong");
		System.out.println("Is m2 alive ? "+m2.isAlive());
		System.out.println("m2's name   ? "+m2.getName());
		m2.start(); //4
		System.out.println("Is m2 alive ? "+m2.isAlive());
		
		
		System.out.println("End main");
	
	}

}
