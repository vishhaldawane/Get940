class Account
{
	private int acno;
	private String name;
	private float balance;
	
	public Account(int acno, String name, float balance) {
		super();
		this.acno = acno;
		this.name = name;
		this.balance = balance;
	}
	
	synchronized void deposit(float amt, String tab) {
		System.out.println(tab+"Depositing..."+amt);
		float calcAmt = getBalance(tab) + amt;
		setBalance(calcAmt,tab);
		System.out.println(tab+"Deposited...."+amt);
	}
	synchronized private void setBalance(float amt,String tab) {
		System.out.println(tab+"Setting the balance...");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		balance = amt;
		System.out.println(tab+"Balance Set...");
	}
	synchronized private float getBalance(String tab) {
		System.out.println(tab+"Getting the balance...");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(tab+"Balance Got...");
		return balance ;
	}
	void showAccount() {
		System.out.println("Acno : "+acno);
		System.out.println("Name : "+name);
		System.out.println("Bal  : "+balance);
		System.out.println("------------------------");
	}
}

class Transaction extends Thread //1
{
	Account x;
	float amtToDeposit;
	String tab;
	
	Transaction(Account r, float amt, String t) {
		x = r;
		amtToDeposit = amt;
		tab = t;
	}
	
	public void run() {
		x.deposit(amtToDeposit,tab);
	}
}
public class SyncTest {

	public static void main(String[] args) {
		Account a = new Account(10,"Suresh",45000);
		a.showAccount();
		
		Transaction t1 = new Transaction(a,5000,"\t t1:");
		Transaction t2 = new Transaction(a,7000,"\t\t t2:");
		Transaction t3 = new Transaction(a,8000,"\t\t\t t3:");
		
		System.out.println("Threads will start after 10 secs");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		t1.start();
		t2.start();
		t3.start();
		
		try {
			t1.join();
			t2.join();
			t3.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Account would be shown after 10 secs");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		a.showAccount();
		System.out.println("End of main");
	}
}
