
class Bank
{
	public static void main(String args[])
	{
		System.out.println("Begin banking...");
		Account a = new Account(101,"Suresh",1500);
		a.showAccount();


		//a.balance = 50000;
		
		a.showAccount();
	

		System.out.println("End banking...");
	}
}

class Account
{
	private int acno;
	private String name;
	private double balance;
	
	Account(int acno, String name, double balance)
	{
		System.out.println("Account(int,String,double)...");
		if(acno<0)
			System.out.println("Negative account number...");
		else
			this.acno = acno;
		
		char ch; 	boolean found = false;
		
		for(int i=0;i<name.length();i++) {
			ch = name.charAt(i);
			if( (ch>=65 && ch<=90) || (ch>=97 && ch<=122) )
				found=true;
			else { 	
				found=false; 	
				break; 
			}
		}
		if(found==false)
			System.out.println("Invalid String...");
		else
			this.name = name;
		
		if(balance < 0 ) 
			System.out.println("Negative balance .....");
		else
			if(balance <1000) 
				System.out.println("Minimum balance not maintained.....");
			else
				this.balance = balance;
	}
	
	Account(int x)
	{
		this(x,"",0); // invoke ctor of the same class
		System.out.println("Account(int)...");
		
	}
	
	Account(String y)
	{
		this(0,y,0);
		System.out.println("Account(String)...");
		
	}

	void initialize(int x, String y, double z)
	{
		acno = x;
		name = y;
		balance = z;
	}
	void showAccount()
	{
		System.out.println("Acno : "+acno);
		System.out.println("Name : "+name);
		System.out.println("AcBal: "+balance);
		System.out.println("-------------------------");

	}
	void withdraw(float amt)
	{
	  System.out.println("Withdrawing......"+amt);
	  balance = balance - amt;
	}
	void deposit(float amt)
	{
	  System.out.println("Depositing......"+amt);
	  balance = balance + amt;
	}
	double getBalance() 
	{
		return balance;
	}
}