class Math
	{
		float avg(int i, int j)
		{
			System.out.println("avg(int,int)");
			return (i+j)/2;
		}

		float avg(int i, int j, int k)
		{
			System.out.println("avg(int,int,int)");
			return (i+j+k)/3;
		}

		float avg(float i,float j)
		{
			System.out.println("avg(float,float)");
			return (i+j)/2;
		}

		float avg(int i, float j)
		{
			System.out.println("avg(int,float)");
			return (i+j)/2;
		}

		float avg(float i, int j)
		{
			System.out.println("avg(float,int)");
			return (i+j)/2;
		}
	}

public class OverloadingTest {
	public static void main(String[] args) {
		Math m = new Math();
		
		System.out.println("avg : "+m.avg(10,20));
		System.out.println("avg : "+m.avg(10,20,30));
		System.out.println("avg : "+m.avg(50.5f,70.6f));
		System.out.println("avg : "+m.avg(30,80.4f));
		System.out.println("avg : "+m.avg(58.3f,90));

	}

}
