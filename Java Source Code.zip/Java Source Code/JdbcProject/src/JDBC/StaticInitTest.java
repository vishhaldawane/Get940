class Test
{
	static int no;
	static
	{
		no = 50;
		System.out.println("Hello this is in static initializer");
	}
	Test()
	{
		System.out.println("Hello, this is constructor");
	}
};

public class  StaticInitTest
{
	public static void main(String[] args) 
	{
		System.out.println("here the program begins");
		Test t1 = new Test();
		Test t2 = new Test();
		System.out.println("Value of no is : "+Test.no);
	}
}
