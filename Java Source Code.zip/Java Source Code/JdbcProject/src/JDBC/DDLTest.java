import java.sql.*;

public class  DDLTest
{
	public static void main(String[] args) throws InterruptedException
	{
		if(args.length!=1)
		{
			System.out.println("USAGE : DDLTest <tablename>");
			System.exit(1);
		}

		String tname = args[0];

		try
		{
			DriverManager.registerDriver(new sun.jdbc.odbc.JdbcOdbcDriver());
			System.out.println("Driver registered...");
			Connection conn = DriverManager.getConnection("jdbc:odbc:mydsn","scott","tiger");
			System.out.println("Connected to the database...");
			Statement st = conn.createStatement();
			System.out.println("Statement created...");
			String sql = "create table "+tname+"( first number(5), second varchar2(20))";
			st.executeUpdate(sql);
			System.out.println("Table successfully created....");
			st.close(); //close the statement
			conn.close(); //close the connection with oracle
		}
		catch (SQLException e)
		{
			System.out.println("Problem in creating table : "+e);
		}
	}
}
