import java.sql.*;

public class  SelectTest
{
	public static void main(String[] args) throws InterruptedException
	{
		try
		{
			DriverManager.registerDriver(new sun.jdbc.odbc.JdbcOdbcDriver());
			System.out.println("Driver registered...");
			Connection conn = DriverManager.getConnection("jdbc:odbc:mydsn","scott","tiger");
			System.out.println("Connected to the database...");
			Statement st = conn.createStatement();
			System.out.println("Statement created...");
			ResultSet rs = st.executeQuery("select empno,ename,job,sal,deptno from scott.emp");
			System.out.println("Received result set...\n\n");
			
			int eno,dno;
			String ename, job;
			float sal;

			while(rs.next()) //process the result set
			{
				eno = rs.getInt(1);
				ename = rs.getString("ename");
				job = rs.getString(3);
				sal = rs.getFloat("sal");
				dno = rs.getInt(5);

				System.out.println(eno + "\t\t"+ename+"\t\t"+job+"   \t"+sal+"\t\t"+dno);
				Thread.sleep(50);
			}
			rs.close(); //close the result set
			st.close(); //close the statement
			conn.close(); //close the connection with oracle
		}
		catch (SQLException e)
		{
			System.out.println("Error : "+e);
		}
	}
}
