import java.sql.*;
import java.io.*;

public class  UpdateTest
{
	public static void main(String[] args) throws InterruptedException
	{
		try
		{
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			System.out.println("Enter increment amount : ");
			String s = br.readLine();
			int incr = Integer.parseInt(s);
			System.out.println("Enter new job : ");
			String njob = br.readLine();
			System.out.println("Enter for which deptno : ");
			String d = br.readLine();
			int dno = Integer.parseInt(d);

			DriverManager.registerDriver(new sun.jdbc.odbc.JdbcOdbcDriver());
			System.out.println("Driver registered...");
			Connection conn = DriverManager.getConnection("jdbc:odbc:mydsn","scott","tiger");
			System.out.println("Connected to the database...");
			PreparedStatement pst = conn.prepareStatement("update emp set sal = sal + ?, job = ? where deptno="+dno);
			System.out.println("Statement prepared...");
			pst.setInt(1,incr);
			pst.setString(2,njob);

			int rows = pst.executeUpdate();
			System.out.println("number of rows updated.."+rows);
			pst.close(); //close the statement
			conn.close(); //close the connection with oracle
		}
		catch (Exception e)
		{
			System.out.println("Problem  : "+e);
		}
	}
}
