import java.sql.*;

public class  SelectCondTest
{
	public static void main(String[] args) throws InterruptedException
	{
		if(args.length==0)
		{
			System.out.println("USAGE : SelectCondTest <job>");
			System.exit(1);
		}
		String vjob = args[0];

		try
		{
			DriverManager.registerDriver(new sun.jdbc.odbc.JdbcOdbcDriver());
			System.out.println("Driver registered...");
			Connection conn = DriverManager.getConnection("jdbc:odbc:mydsn","scott","tiger");
			System.out.println("Connected to the database...");
			Statement st = conn.createStatement();
			System.out.println("Statement created...");
			ResultSet rs = st.executeQuery("select * from emp where job="+"'"+vjob+"'");
			System.out.println("Received result set...");
			ResultSetMetaData rsmd = rs.getMetaData();
			System.out.println("Received meta data...\n\n");

			int cols = rsmd.getColumnCount();

			System.out.println("\n==========================================================================");
			for (int i=1; i<=5; i++)
			{
				System.out.print(rsmd.getColumnName(i)+"\t\t");
			}
			System.out.println("\n==========================================================================");

			System.out.println("");
		
			while(rs.next()) //process the result set
			{
				System.out.print(rs.getInt(1)+"\t\t");
				System.out.print(rs.getString(2)+"\t\t");
				System.out.print(rs.getString(3)+"\t\t");
				System.out.print(rs.getInt(4)+"\t\t");
				System.out.print(rs.getDate(5)+"\t\t");
				/*System.out.print(rs.getFloat(6)+"\t");
				System.out.print(rs.getFloat(7)+"\t");
				System.out.print(rs.getInt(8)+"\t");*/
				System.out.println("\n--------------------------------------------------------------------------");
				Thread.sleep(50);
			}
			rs.close(); //close the result set
			st.close(); //close the statement
			conn.close(); //close the connection with oracle
		}
		catch (SQLException e)
		{
			System.out.println("Error : "+e);
		}
	}
}
