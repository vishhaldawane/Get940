import java.sql.*;

public class  DeleteTest
{
	public static void main(String[] args) throws InterruptedException
	{
		if(args.length!=1)
		{
			System.out.println("USAGE : DeleteTest <deptno>");
			System.exit(1);
		}

		int vdno = Integer.parseInt(args[0]);

		try
		{
			DriverManager.registerDriver(new sun.jdbc.odbc.JdbcOdbcDriver());
			System.out.println("Driver registered...");
			Connection conn = DriverManager.getConnection("jdbc:odbc:mydsn","scott","tiger");
			System.out.println("Connected to the database...");
			Statement st = conn.createStatement();
			System.out.println("Statement created...");
			String sql = "delete from emp where deptno="+vdno;
			int rows = st.executeUpdate(sql);
			System.out.println("Number of rows deleted..."+rows);

			st.close(); //close the statement
			conn.close(); //close the connection with oracle
		}
		catch (SQLException e)
		{
			System.out.println("Error : "+e);
		}
	}
}
