public class  StaticInitTest1
{
	public static void main(String[] args) 
	{
		try
		{
			Class.forName(args[0]);
			System.out.println("class loaded : "+args[0]);
		}
		catch (ClassNotFoundException e)
		{
			System.out.println("Unable to load class "+e);
		}
	}
}
