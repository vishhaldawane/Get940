import java.sql.*;

public class  InsertTest
{
	public static void main(String[] args) throws InterruptedException
	{
		if(args.length!=5)
		{
			System.out.println("USAGE : InsertTest <empno> <ename> <job> <sal> <deptno>");
			System.exit(1);
		}

		int eno = Integer.parseInt(args[0]);
		String name = args[1];
		String job = args[2];
		float sal = Float.parseFloat(args[3]);
		int dno = Integer.parseInt(args[4]);

		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			System.out.println("Driver registered...");
		}
		catch (ClassNotFoundException e)
		{
			System.out.println("Unable to load Driver...");
			System.exit(2);
		}

		try
		{
			Connection conn = DriverManager.getConnection("jdbc:odbc:mydsn","scott","tiger");
			System.out.println("Connected to the database...");
			PreparedStatement pst = conn.prepareStatement("insert into emp (empno, ename,job,sal,deptno) values (?,?,?,?,?)");
			System.out.println("Statement prepared...");
			pst.setInt(1,eno);
			pst.setString(2,name);
			pst.setString(3,job);
			pst.setFloat(4,sal);
			pst.setInt(5,dno);
			
			int rows = pst.executeUpdate();
			System.out.println("number of rows inserted..."+rows);
			pst.close(); //close the statement
			conn.close(); //close the connection with oracle
		}
		catch (SQLException e)
		{
			System.out.println("Problem in creating table : "+e);
		}
	}
}
