import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class DeleteTest {

	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		
		System.out.println("Delete rows of which deptno ? ");
		int dno = MyIOServices.getInt();

		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			System.out.println("Driver loaded...");
		
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL", "scott","tiger");
			System.out.println("Connected to : "+conn);
			
			
			PreparedStatement pst = conn.prepareStatement("delete from emp where deptno=?");
			pst.setInt(1, dno);
			
			int row = pst.executeUpdate();
			conn.rollback();
			//System.out.println("Committed...");
			
			System.out.println(row+" row deleted...");

			pst.close();
			conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
				

	}

}
