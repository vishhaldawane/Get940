import java.util.Comparator;

class ArtistComparator implements Comparator<Song>
{
	public int compare(Song arg0, Song arg1) {
		System.out.println("Comparator: Comparing on basis of Artist");
		return arg0.artist.compareTo(arg1.artist);
	}
}

class AlbumComparator implements Comparator<Song>
{
	public int compare(Song arg0, Song arg1) {
		System.out.println("Comparator: Comparing on basis of Album");
		return arg0.album.compareTo(arg1.album);
	}
}

class TitleComparator implements Comparator<Song>
{
	public int compare(Song arg0, Song arg1) {
		System.out.println("Comparator: Comparing on basis of Title");
		return arg0.title.compareTo(arg1.title);
	}
}

class YearComparator implements Comparator<Song>
{
	public int compare(Song arg0, Song arg1) {
		System.out.println("Comparator: Comparing on basis of Year");
		return Integer.compare(arg0.year,arg1.year);
	}
}

public class Song implements Comparable<Song> // java.lang
{
	String title;
	String album;
	String artist;
	
	int year;

	
	public int compareTo(Song arg0) {
		//return title.compareTo(arg0.title);
		System.out.println("Comparable: Comparing on basis of year");
		return Integer.compare(year, arg0.year);
	}
	Song() {
		System.out.println("Song ctr...");
	}
	public Song(String title, String album, String artist, int year) {
		super();
		this.title = title;
		this.album = album;
		this.artist = artist;
		this.year = year;
	}
	
	public String toString() {
		return title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	
	
	
	
}