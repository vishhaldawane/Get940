import java.sql.*;
import java.io.*;

public class  FunCallTest
{
	public static void main(String[] args) throws InterruptedException
	{
		if (args.length==0)
		{
			System.out.println("USAGE : FunCallTest <empno>");
			System.exit(1);
		}

		try
		{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			System.out.println("Driver registered...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");
			System.out.println("Connected to the database...");
		
			CallableStatement cst = conn.prepareCall(" { ? =  call GetNet (?) } ");
			System.out.println("Callable statement prepared...");
			int eno = Integer.parseInt(args[0]);

			cst.setInt(2,eno);
			cst.registerOutParameter(1,Types.FLOAT);

			cst.executeUpdate();

			float net = cst.getFloat(1);

			System.out.println("EMP NET SALARY : "+net);

			cst.close(); //close the statement
			conn.close(); //close the connection with oracle
		}
		catch (Exception e)
		{
			System.out.println("Problem  : "+e);
			e.printStackTrace();
		}
	}
}
