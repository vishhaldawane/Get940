import java.awt.Container;
import java.awt.FlowLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.ListModel;
class SongFrame extends JFrame
{
	
	JList jl;
	JTable jt ;
	JButton jb1 = new JButton("Sort by Title");
	JButton jb2 = new JButton("Sort by Album");
	JButton jb3 = new JButton("Sort by Artist");
	JButton jb4 = new JButton("Sort by year");
	Song ary[];
	ArrayList<Song> al = new ArrayList<Song>();
	
	SongFrame() {
		
		setLayout(new FlowLayout());
		setSize(400, 400);
		setLocation(100, 100);
		

		add(jt);
		add(jb1);add(jb2);add(jb3);add(jb4);
		ResultSet rs = loadData();
		ary = populateArray(rs);
		

		for (int i = 0; i < ary.length; i++) {
			System.out.println("Adding song into ArrayList");
			al.add(ary[i]);
		}
		
		String headings[]={"Title"};
		
		String data[][]={
				{"col1"},
				{"col2"},
				{"col3"}
		};
		
		jt = new JTable(data, headings);
		System.out.println("Done");
	}
	
	Song[] populateArray(ResultSet rs)
	{
		Song ary[] = null;
		try {
			rs.last();
			int num = rs.getRow();
			ary = new Song[num];
			
			int i=0;
			
			rs.beforeFirst();
			
			while (rs.next()) 
			{
				ary[i] = new Song();
				ary[i].setTitle(rs.getString(1));
				ary[i].setAlbum(rs.getString(2));
				ary[i].setArtist(rs.getString(3));
				ary[i].setYear(rs.getInt(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Returning array..");
		return ary;
	}
	
	ResultSet loadData() {
		ResultSet rs = null;
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			System.out.println("Driver loaded...");
			
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL", "scott","tiger");
			System.out.println("Connected to : "+conn);
			
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
			System.out.println("Statement created.."+st);
			
			rs = st.executeQuery("select * from SongMaster");
			System.out.println("ResultSet got.."+rs);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return rs;
	}
}


public class SongTest {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SongFrame sf = new SongFrame();
		sf.setVisible(true);
	}

}
