import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class UpdateTest {

	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		System.out.println("Enter salary amount to add : ");
		float amt = MyIOServices.getFloat();
		
		System.out.println("For which designation ? ");
		String desg = MyIOServices.getString();

		System.out.println("Of which deptno ? ");
		int dno = MyIOServices.getInt();

		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			System.out.println("Driver loaded...");
		
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL", "scott","tiger");
			System.out.println("Connected to : "+conn);
			
			conn.setAutoCommit(false);
			System.out.println("Autocommit is false....");
			PreparedStatement pst = conn.prepareStatement("update emp set sal=sal+? where job=? and deptno=?");
			pst.setFloat(1, amt);
			pst.setString(2, desg);
			pst.setInt(3, dno);
			
			int row = pst.executeUpdate();
			conn.rollback();
			//System.out.println("Committed...");
			
			System.out.println(row+" row updated...");

			pst.close();
			conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
				

	}

}
