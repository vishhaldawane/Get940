import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


class MyIOServices
{
	private static InputStreamReader isr  = new InputStreamReader(System.in);
	private static BufferedReader buff = new BufferedReader(isr);
	
	static int getInt() throws NumberFormatException, IOException {
		return Integer.parseInt(buff.readLine());
	}
	static String getString() throws IOException {
		return buff.readLine();
	}
	public static Float getFloat() throws NumberFormatException, IOException {
		return Float.parseFloat(buff.readLine());
	}
	
}
public class InsertTest {

	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		System.out.println("Enter dept no : ");
		int dno = MyIOServices.getInt();
		
		System.out.println("Enter dept name : ");
		String dname = MyIOServices.getString();
		
		System.out.println("Enter dept location : ");
		String loc = MyIOServices.getString();
		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			System.out.println("Driver loaded...");
		
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL", "scott","tiger");
			System.out.println("Connected to : "+conn);
			
			PreparedStatement pst = conn.prepareStatement("insert into dept values(?,?,?)");
			pst.setInt(1, dno);
			pst.setString(2, dname);
			pst.setString(3, loc);
			
			int row = pst.executeUpdate();
			
			System.out.println(row+" row created...");

			pst.close();
			conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
				

	}

}
