import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


//alter user scott account unlock; 
//alter user scott identified by mypassword;

public class SelectTest {

	public static void main(String[] args) {
	
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			System.out.println("Driver loaded...");
			
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "scott","tiger");
			System.out.println("Connected to : "+conn);
			
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
			System.out.println("Statement created.."+st);
			
			ResultSet rs = st.executeQuery("select * from emp order by deptno");
			System.out.println("ResultSet got.."+rs);
			
			while(rs.next()) {
				System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(2)+"\t"+rs.getFloat(6)+"\t"+rs.getInt(8));
			}
			
			
			rs.close();
			st.close();
			conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
