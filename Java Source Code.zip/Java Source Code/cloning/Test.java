
class Department{
  String dname;
    Department(String n) {
    	dname = n;
    }
    public String toString() {
 	return dname;
    }
    void changeDeptName(String n) {
	dname = n;
    }
    protected Department clone(){
       	super.clone();
	return new Department();
    }
}


class Employee{

  int age;
  String name;

  Department dept;
    Employee(int a, String n, Department d) {
    	age = a;
	name = n;
	dept = d;
    }
    public String toString() {
 	return age+" "+name+" "+dept;
    }
    protected Employee clone() throws CloneNotSupportedException {
	super.clone();
	Employee x = (Employee) super.clone();
	x.age = this.age;
	x.name = name;
	x.dept = dept.clone();
	return x;	
    }
}

public class Test {
  public static void main(String args[]) {

	Department d=new Department("QUALITY");
	Employee e1 = new Employee(10,"Jack",d);
	Employee e2 = e1.clone();

	System.out.println("e1 : "+e1);
	System.out.println("e2 : "+e2);

	System.out.println("----------------------");
	e2.age = 20;
	e2.dept.dname="QA";

	System.out.println("e1 : "+e1);
	System.out.println("e2 : "+e2);
	
	
	
  }
}