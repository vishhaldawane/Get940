import java.awt.Frame;


public class FrameTest {

	public static void main(String[] args) {

		Frame f[] = new Frame[5];
		
		int x=100,y=200;
		
		for(int i=0;i<5;i++,x=x+50,y=y+50)
		{
			f[i] = new Frame("Vishal");
			f[i].setSize(x, y);
			f[i].setVisible(true);
		}

	}

}
