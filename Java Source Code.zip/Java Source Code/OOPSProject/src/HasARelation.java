class Engine {
	private String engineMake;
	private int capacity;

	public Engine(String engineMake, int capacity) {
		super();
		this.engineMake = engineMake;
		this.capacity = capacity;
	}

	private void ignition() {
		System.out.println("Starting...engine..");
	}

	private void spark() {
		System.out.println("Sparking....");
	}

	void startEngine() {
		spark();
		ignition();
		System.out.println("Engine started...");
	}

	public void showEngine() {
		
		System.out.println("Engine make     : "+engineMake);
		System.out.println("Engine capacity : "+capacity);
		
	}
}

class Vehicle {
	int num;
	String name;
	Engine e; // here e is the data member of Vehicle

	public Vehicle(int num, String name, String make, int cap) {
		super();
		this.num = num;
		this.name = name;
		this.e = new Engine(make,cap);
	}

	void startVehicle() {
		e.startEngine();
		System.out.println("Vehicle...started...");
	}
	void showVehicle() {
		System.out.println("Vehicle num     : "+num);
		System.out.println("Vehicle name    : "+name);
		e.showEngine();
	}
}

public class HasARelation {
	public static void main(String[] args) {
		Vehicle v1 = new Vehicle(101,"TataManza","Fiat",2);
		
		v1.showVehicle();
		
		v1.startVehicle();
	}
}


