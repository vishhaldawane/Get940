class Account {
	private int acno;
	private String name;
	private double balance;

	public void setBalance(double balance) {
		if (balance <= 0) {
			System.out.println("Balance must not be negative....");
		}
		else
			this.balance = balance;
	}
	
	public int getAcno() {
		// TODO Auto-generated method stub
		return acno;
	}

	Account(int acno, String name, double balance) {
		System.out.println("Account(int,String,double)...");
		if (acno < 0)
			System.out.println("Negative account number...");
		else
			this.acno = acno;

		char ch;
		boolean found = false;

		for (int i = 0; i < name.length(); i++) {
			ch = name.charAt(i);
			if ((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122))
				found = true;
			else {
				found = false;
				break;
			}
		}
		if (found == false)
			System.out.println("Invalid String...");
		else
			this.name = name;

		if (balance < 0)
			System.out.println("Negative balance .....");
		else if (balance < 1000)
			System.out.println("Minimum balance not maintained.....");
		else
			this.balance = balance;
	}

	Account(int x) {
		this(x, "", 0); // invoke ctor of the same class
		System.out.println("Account(int)...");

	}

	Account(String y) {
		this(0, y, 0);
		System.out.println("Account(String)...");

	}

	Account() {

	}

	void initialize(int x, String y, double z) {
		acno = x;
		name = y;
		balance = z;
	}

	void showAccount() {
		System.out.println("Acno : " + acno);
		System.out.println("Name : " + name);
		System.out.println("AcBal: " + balance);
		System.out.println("-------------------------");

	}

	void withdraw(double amt) {
		System.out.println("Withdrawing......" + amt);
		if (amt < 0) {
			System.out.println("Withdraw amount must not be negative...");
		} else
			balance = balance - amt;
	}

	void deposit(double amt) {
		System.out.println("Depositing......" + amt);
		if (amt < 0) {
			System.out.println("Deposit amount must not be negative...");
		} else
			balance = balance + amt;
	}

	double getBalance() {
		return balance;
	}
}

class SavingsAccount extends Account {
	float rate; // inherited data members-> acno,name,balance

	SavingsAccount(int a, String b, double c, float d) // explicit ctor - no-arg
														// ctor
	{
		super(a, b, c);
		System.out.println("SavingsAccount(int,String,double,float) ctor");
		rate = d;
	}

	void setRate(float r) {
		System.out.println("Setting rate ...");
		rate = r;
	}

	float getRate() {
		return rate;
	}

	double calculateSI() {
		return (getBalance() * 1 * rate / 100);
	}

	void showAccount() { // overriding -
							// expand the behaviour of
							// super class's showAccount()

		super.showAccount();
		System.out.println("Rate : " + rate);
		System.out.println("SI   : " + calculateSI());
	}

	void withdraw(double amt) { // override
		if (getBalance() - amt < 1000) {
			System.out
					.println("Account balance not maintained...Insufficient Funds...");
		} else
			super.withdraw(amt);
	}

	
}

class CurrentAccount extends Account {
	float creditLimit; // inherited data members-> acno,name,balance

	CurrentAccount(int a, String b, double c, float d) // explicit ctor - no-arg
														// ctor
	{
		super(a, b, c);
		System.out.println("CurrentAccount(int,String,double,float) ctor");
		creditLimit = d;
	}

	void setCreditLimit(float c) {
		System.out.println("Setting CreditLimit.....");
		creditLimit = c;
	}

	float getCreditLimit() {
		return creditLimit;
	}

	double calculateOverDraftAmount() {
		return getBalance() * creditLimit;
	}

	void showAccount() { // overriding -
							// expand the behaviour of
							// super class's showAccount()

		super.showAccount();
		System.out.println("Rate     : " + creditLimit);
		System.out.println("OD Amt   : " + calculateOverDraftAmount());
	}

	void withdraw(double amt) { // override
		if (amt > getBalance() + calculateOverDraftAmount()) {
			System.out.println("Account overdraft value exceeded......");
		} else
			super.withdraw(amt);
	}
}

class FixedDepositAccount extends SavingsAccount {
	int maturityYear;

	public FixedDepositAccount(int a, String b, double c, float d,
			int maturityYear) {
		super(a, b, c, d);
		System.out.println("FixedDepositAccount(int,String,double,float,int");
		this.maturityYear = maturityYear;
	}

	public int getMaturityYear() {
		return maturityYear;
	}

	public void setMaturityYear(int maturityYear) {
		System.out.println("Setting the maturity Year");
		this.maturityYear = maturityYear;
	}

	void showAccount() {
		super.showAccount();
		System.out.println("Maturity : " + maturityYear);
	}

	@Override
	void withdraw(double amt) {
		if (maturityYear > 2013) {
			System.out.println("Account not matured....");
		} else {
			if(amt<0) {
				System.out.println("FD cannot have negative value...");
			}
			else
				setBalance(getBalance() - amt);
		}

	}

}

public class InheritanceTest {
	public static void main(String[] args) {

		/*
		 * SavingsAccount sa = new SavingsAccount(101,"Suresh",50000,8.5f);
		 * 
		 * // sa.setRate(5.7f); // SavingsAccount.setRate(sa,5.7f);
		 * 
		 * sa.showAccount(); // Account.showAccount(sa); sa.withdraw(49000);
		 * sa.showAccount();
		 */

		/*
		 * CurrentAccount ca = new CurrentAccount(102,"Rajesh",10000,0.10f);
		 * ca.showAccount();
		 * 
		 * ca.withdraw(10600); ca.showAccount();
		 */

		FixedDepositAccount fda = new FixedDepositAccount(103, "Naresh", 45000,5.7f, 2013);
		fda.showAccount();
		fda.withdraw(45);
		fda.showAccount();

	}

}
