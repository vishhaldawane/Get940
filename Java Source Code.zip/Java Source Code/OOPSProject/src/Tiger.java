
public class Tiger {

	public void jump() {
		// TODO Auto-generated method stub
		
	}

	public void jump(String string) {
		// TODO Auto-generated method stub
		
	}

}
