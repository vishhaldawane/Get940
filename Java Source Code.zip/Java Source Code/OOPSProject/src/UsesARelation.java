class Cashier
{
	
	void prepareBalanceSheets() {
		System.out.println("Cashier preparing balance sheets..");
	}
	void stampCheques() {
		System.out.println("Cashier stamping...cheques..");
	}
				//usesA relationship
	void dispenseCash(SavingsAccount x, float amt) {
		System.out.println("Cashier dispensing cash...to "+x.getAcno());
		x.withdraw(amt);
		System.out.println("-----------------------");
	}
}

public class UsesARelation {
	public static void main(String[] args) {
		Cashier c = new Cashier();
		c.prepareBalanceSheets();
		c.stampCheques();
		c.stampCheques();
		c.stampCheques();
		
		SavingsAccount sa1 = new SavingsAccount(101,"Suresh",50000,8.5f);
		SavingsAccount sa2 = new SavingsAccount(102,"Dinesh",60000,4.5f);
		SavingsAccount sa3 = new SavingsAccount(103,"Jayesh",70000,9.5f);
		
		sa1.showAccount();
		sa2.showAccount();
		sa3.showAccount();
		
		c.dispenseCash(sa1, 5000);
		c.dispenseCash(sa2, 7000);
		c.dispenseCash(sa3, 8000);
		
		
		sa1.showAccount();
		sa2.showAccount();
		sa3.showAccount();
		
		
		
		
	}
}

