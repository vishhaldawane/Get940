import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


public class ArrayListTest {
	
	public static void main(String[] args) {
		int i=10;
		ArrayList a = new ArrayList();
		a.add(i);
		a.add(20);
		
		String str1="Persuit of Happiness";
		String str2="Club cant handle me";
		String str3="Summer of 69";
		String str4="Candy shop";
		String str5="Baby";
		String str6="Persuit of Happiness";
		
		
		System.out.println("Creating jukebox...");
		Collection<String> jukeBox = new ArrayList<String>();
		/*Collection<String> jukeBox = new LinkedList<String>();
		Collection<String> jukeBox = new TreeSet<String>();
		Collection<String> jukeBox = new HashSet<String>();*/
		
		System.out.println("Adding song names to jukebox...");
		jukeBox.add(str1);
		jukeBox.add(str2);
		jukeBox.add(str3);
		jukeBox.add(str4);
		jukeBox.add(str5);
		jukeBox.add(str6);
		
	
		System.out.println("Showing jukebox contents...");
		
		Iterator<String> iter = jukeBox.iterator();
		
		while(iter.hasNext()) {
			String str = iter.next();
			System.out.println("Song title :"+str);
		}
		
		
		

	}

}
