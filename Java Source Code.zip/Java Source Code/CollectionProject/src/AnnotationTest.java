import java.util.Date;



@IndianKitchen
class Kitchen1 extends kitchen
{
	@IndianSalt("puresalt")
	void salt() {
		
	}
}

@ChineseKitchen
class Kitchen2 extends kitchen
{
	
	void salt() {
		
	}

}

class Savings
{
	@Deprecated
	void withdraw(float amt) { 
		
	}
	
	void withdraw(float amt, boolean arg) { 
		
	}
	
}

class MyDate extends Date
{

	public int getDay() {
		return 0;
	}
}
public class AnnotationTest {
	public static void main(String[] args) {
		
		
		Date d = new Date();
		
		@SuppressWarnings("deprecation")
		int dn=d.getDay();
		
		System.out.println(""+dn);
	}
}














