import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class Flight
{
	int flno;
	String name;
	int seats;
	
	public void fun() {
		System.out.println("Flight fun");
		
		try
		{
			//...open file
			// ...operate data
			// ...close file
		}
		
		
		catch(ArithmeticException e) { }
		catch(NullPointerException e) { }
		catch(RuntimeException e) { }
		catch(Exception e) { }
		
	}
	
	public Flight(int i) {
		System.out.println("Flight(int)");
	}
	
	public Flight() {
		System.out.println("Flight()");
	}
	
	public Flight(String s) {
		System.out.println("Flight(String)");
	}
	public void show() {
		System.out.println("Flight show");
	}
}
public class ReflectionTest {
	public static void main(String[] args) {
		
		Flight f = new Flight();
		
		Class x = f.getClass();
		
		Method m[] = x.getMethods();
		
		for (int i = 0; i < m.length; i++) {
			System.out.println("Methods : "+m[i].getName());
		}
		
		Constructor ctrs[] = x.getConstructors();
		for (int i = 0; i < ctrs.length; i++) {
			System.out.println("CTORS : "+ctrs[i].getName());
		}
		
		try {
			
			m[0].invoke(f, null);
			
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}	














