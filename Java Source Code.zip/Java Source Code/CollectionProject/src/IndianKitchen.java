
public @interface IndianKitchen {

}
