import java.util.Calendar;
import java.util.TimeZone;

public class CalendarTest {
	public static void main(String[] args) {

		/*String ary[] = TimeZone.getAvailableIDs();
		for (int i = 0; i < ary.length; i++) {
			System.out.println(ary[i]);
		}*/
		
		TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
		Calendar cal = Calendar.getInstance(tz);
		
		System.out.println("Day   : "+cal.get(Calendar.DAY_OF_MONTH));
		System.out.println("Month : "+cal.get(Calendar.MONTH));
		System.out.println("Year  : "+cal.get(Calendar.YEAR));
		
		System.out.println("HH : "+cal.get(Calendar.HOUR_OF_DAY));
		System.out.println("MM : "+cal.get(Calendar.MINUTE));
		System.out.println("SS : "+cal.get(Calendar.SECOND));
		System.out.println("MS : "+cal.get(Calendar.MILLISECOND));
		
		
	}
}
