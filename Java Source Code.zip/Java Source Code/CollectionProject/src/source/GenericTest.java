import java.awt.event.*;

class Box<T> {
  T o;
	Box(T o) { // mutuator
		this.o=o;
	}
	void add(T o) {
		this.o = o;
	}
	T get() { //accessor
		return o;
	}
	<U extends Number> void swap(U i, U j) {
		U temp;
		temp=i;
		i = j;
		j = temp; 
	}

}

public class GenericTest {
	
	static void showBox(Box<Number> x) {
		
	}
	
	public static void main(String[] args) {
		Integer i = new Integer(10);
		Double j = new Double(20.5);
	
		Box<Number> b1 = new Box<Number>(i);
		b1.add(i);
		b1.add(j);
		showBox(b1);
		
		
		
		/*System.out.println("i : "+i);
		System.out.println("j : "+j);
		//make this box to store only Integers
		Box<Integer> b1 = new Box<Integer>(i);
		//b1.swap(i,"something");
		System.out.println("After swap.....");
		
		System.out.println("i : "+i);
		System.out.println("j : "+j);
		
		Integer x  = (Integer) b1.get();
		System.out.println("x : "+x);

		//done by somebody..no error
		Box <Integer>b2 = new Box<Integer>(20);

		Box <String>b3 = new Box<String>("jack");
		//extraction dobe by you

		Integer y  = (Integer) b2.get();
		System.out.println("y : "+y);
		 */
	}
}



