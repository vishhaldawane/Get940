import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

/*
class Employee {
	int empno;
	String name;
	float salary;
	public Employee(int empno, String name, float salary) {
		super();
		this.empno = empno;
		this.name = name;
		this.salary = salary;
	}
	public String toString() {
	
		return empno+" "+name+" "+salary;
	}
}*/


class Student {
	int rno;
	String name;
	float marks;
	public Student(int rno, String name, float marks) {
		super();
		this.rno = rno;
		this.name = name;
		this.marks = marks;
	}
	public String toString() {
	
		return rno+" "+name+" "+marks;
	}
}

public class VectorTest1 {
	
	public static void main(String[] args)throws IOException {
		
		Vector v = new Vector(5);
		System.out.println("Empty vector...");
		System.out.println("v size     : "+v.size());
		System.out.println("v capacity : "+v.capacity());
		
		System.in.read();
		
		Employee e1 = new Employee(10,"Jack",1000);
		Employee e2 = new Employee(20,"Jane",2000);
		Employee e3 = new Employee(30,"Jill",3000);
		System.out.println("adding 3 employees");
		v.addElement(e1);
		v.addElement(e2);
		v.addElement(e3);
	
		System.out.println("v size     : "+v.size());
		System.out.println("v capacity : "+v.capacity());
		System.in.read();
		
		String cities[]={"Mumbai","Delhi","Kolkatta","Chennai"};
		
		Student s1 = new Student(10,"Martin",45.6f);
		Student s2 = new Student(20,"Miller",65.6f);
		Student s3 = new Student(30,"Merlyn",85.6f);
		
		System.out.println("adding 4 cities");
		for (int i = 0; i < cities.length; i++) {
			v.addElement(cities[i]);
		}
		
		System.out.println("v size     : "+v.size());
		System.out.println("v capacity : "+v.capacity());
		System.in.read();
		
		System.out.println("adding 3 students...");
		v.addElement(s1);
		v.addElement(s2);
		v.addElement(s3);
		System.out.println("v size     : "+v.size());
		System.out.println("v capacity : "+v.capacity());
		System.in.read();
			
		System.out.println("adding 1 string");
		v.addElement(new String("Janet"));
		System.out.println("v size     : "+v.size());
		System.out.println("v capacity : "+v.capacity());
		System.in.read();
		
		System.out.println("---------------------");
		
		for(int i=0;i<v.size();i++) {
			
			Object o = v.elementAt(i);
			
			if ( o instanceof String ) {
				String x = (String) o;
				System.out.println("String is : "+x);
			}
			else if( o instanceof Employee ) {
				Employee x = (Employee) o;
				System.out.println("Employee : "+x);
			}
			else if ( o instanceof Student ) {
				Student x = (Student) o;
				System.out.println("Student : "+x);
			}
			
		}
		
		printStudents(v.elements());
	}
	
	public static void printStudents(Enumeration e) {
	
		System.out.println("-------Enumeration---------");
		while(e.hasMoreElements()) {
			Object o = e.nextElement();
			if(o instanceof Student) {
				Student s = (Student) o;
				System.out.println("Student : "+s);
			}
		}
	}

}
