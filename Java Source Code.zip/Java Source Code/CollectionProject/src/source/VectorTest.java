
public class VectorTest {
	public static void main(String[] args) {
		
	}
}
