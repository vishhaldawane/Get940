import java.util.TreeMap;

class Employee {
	int empno;
	String name;
	float salary;
	public Employee(int empno, String name, float salary) {
		super();
		this.empno = empno;
		this.name = name;
		this.salary = salary;
	}
	public String toString() {
	
		return empno+" "+name+" "+salary;
	}
}
public class MapTest {
	public static void main(String[] args) {
		TreeMap<String, Employee> tm= new TreeMap<String, Employee>();
		Employee e1 = new Employee(10,"Jack",5000);
		Employee e2 = new Employee(20,"Jane",6000);
		Employee e3 = new Employee(30,"Jill",7000);
		
		tm.put("A101", e1);
		tm.put("A102", e2);
		tm.put("A103", e3);
		
		Employee x = (Employee) tm.get("A105");
		System.out.println("x "+x);
		
		
	}
}
