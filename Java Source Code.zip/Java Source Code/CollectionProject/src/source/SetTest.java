import java.util.TreeSet;


public class SetTest {

	public static void main(String[] args) {
		TreeSet<Integer> ts = new TreeSet<Integer>();
		ts.add(new Integer(10));
		ts.add(new Integer(5));
		ts.add(new Integer(15));
		ts.add(new Integer(25));
		ts.add(new Integer(35));
		ts.add(new Integer(3));
		
		Object o[] = ts.toArray();
		for (int i = 0; i < o.length; i++) {
			Integer x  = (Integer) o[i];
			System.out.println("x:"+x);
		}
	}
}
