
class IntegerStack {
	private int top=-1;
	int buffer[];
	
	IntegerStack (int capacity) {
		buffer = new int [ capacity ];
	}
	void push(int item) {
		buffer [ ++top ] = item ;
	}
	int pop() {
		return buffer [ top-- ];
	}
}

public class StackTest {

	public static void main(String[] args) {
			IntegerStack is = new IntegerStack(5);
			is.push(10);
			is.push(20);
			is.push(30);
			is.push(40);
			is.push(50);
			
			System.out.println("is :"+is.pop());
			System.out.println("is :"+is.pop());
			System.out.println("is :"+is.pop());
			System.out.println("is :"+is.pop());
			System.out.println("is :"+is.pop());
			
	}

}
