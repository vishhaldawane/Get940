import java.util.*;
import java.io.*;

public class ClockTime {
	public static void main(String[] args) {
/*		String countries [] = {"America/New_York",
				"Asia/Tokyo",
				"Europe/London",
				"Asia/Kolkata"
		};*/
		
		String countries[] = TimeZone.getAvailableIDs();
		/*for (int i = 0; i < countries.length; i++) {
			System.out.println(countries[i]);
		}*/
		//Console c = System.console();
		//System.out.println("c:"+c);
		
//		c.format("\nHello : [%5d]",new Integer(100));
	//	c.format("\nHello : [%10d]",new Integer(100));
		
		Calendar cal[]= new Calendar[countries.length];
		
		for (int i = 0; i < countries.length; i++) {
				TimeZone tz = TimeZone.getTimeZone(countries[i]);
				cal[i] = Calendar.getInstance(tz);
				
				//c.format("\n[%-30s]",countries[i]);
				System.out.print(" "+countries[i]);
				System.out.print(+cal[i].get(Calendar.DAY_OF_MONTH));
				System.out.print("/"+cal[i].get(Calendar.MONTH)+1);
				System.out.print("/"+cal[i].get(Calendar.YEAR)+"\t");
				System.out.print(cal[i].get(Calendar.HOUR_OF_DAY));
				System.out.print(":"+cal[i].get(Calendar.MINUTE));
				String AMPM;
				if(cal[i].get(Calendar.AM_PM) == 0 )
					AMPM="AM";
				else
					AMPM="PM";
					
				System.out.print(" "+AMPM);
				System.out.println("\n---------------------");
				
		}
	}
}
