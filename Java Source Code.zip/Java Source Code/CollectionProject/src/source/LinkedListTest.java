import java.util.*;
class Flight {
	 private int fno;
	 String name;
	 int seats;
	 Flight(int fno, String name, int seats) {
		this.fno = fno;		this.name = name;		this.seats = seats;
	}
	public String toString() {
		return fno+" "+name+" "+seats;
	}
}

public class LinkedListTest {
	public static void main(String[] args) {
		LinkedList l = new LinkedList();
		Vector v = new Vector();
		
		Flight f1 = new Flight(10,"JetAirways",100);
		Flight f2 = new Flight(20,"AirIndia",100);
		Flight f3 = new Flight(30,"KingFisher",100);
		
		l.add(f1);
		l.add(f2);
		l.add(f3);
		
		v.add(f1);
		v.add(f2);
		v.add(f3);
		
		Iterator iter = l.iterator(); 
		Calendar now =  Calendar.getInstance();
		while(iter.hasNext()) {
			Flight element = (Flight) iter.next();
			System.out.println(" "+element);
		} 
		Calendar then =  Calendar.getInstance();
		System.out.println("response : "+(then.get(Calendar.MILLISECOND)-now.get(Calendar.MILLISECOND) ) );
		
		System.out.println("--vector---");
		Enumeration e = v.elements();
		
		now =  Calendar.getInstance();
		while(e.hasMoreElements()) {
			Flight element = (Flight) e.nextElement();
			System.out.println(" "+element);
		}
		then =  Calendar.getInstance();
		System.out.println("response : "+(then.get(Calendar.MILLISECOND)-now.get(Calendar.MILLISECOND) ) );
		
	}
}