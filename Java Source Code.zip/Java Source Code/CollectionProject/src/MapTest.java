import java.util.TreeMap;


public class MapTest {
	public static void main(String[] args) {
		Song s1 = new Song("Persuit of Happiness","Man on moon","Kid Cudi",2010);
		Song s2 = new Song("Club cant handle me","Only one flo","Flo Rida",2011);
		Song s3 = new Song("Summer of 69","Summer of 69","Bryan Adams",1999);
		Song s4 = new Song("Candy shop","The Massacare","50 Cent",2006);
		Song s5 = new Song("Baby","Baby","Justin",2009);
		Song s6 = new Song("Persuit of Happiness","Man on moon","Kid Cudi",2010);
		
		TreeMap<String,Song> tm = new TreeMap<String,Song>();
		
		tm.put("101", s1);
		tm.put("102", s2);
		tm.put("103", s3);
		tm.put("104", s4);
		tm.put("105", s5);
		
		
		if(tm.containsKey("105")) {
			Song x = (Song) tm.get("105");
			System.out.println("x "+x.getTitle());
			System.out.println("x "+x.getArtist());
			System.out.println("x "+x.getAlbum());
			System.out.println("x "+x.getYear());
			
		}
		else {
			System.out.println("Record not found");
		}
		
		
		
		
		
		
	}
}
