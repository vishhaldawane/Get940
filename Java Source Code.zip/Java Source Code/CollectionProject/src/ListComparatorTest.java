import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


public class ListComparatorTest {
	
	public static void main(String[] args) {
		
		Song s1 = new Song("Persuit of Happiness","Man on moon","Kid Cudi",2010);
		Song s2 = new Song("Club cant handle me","Only one flo","Flo Rida",2011);
		Song s3 = new Song("Summer of 69","Summer of 69","Bryan Adams",1999);
		Song s4 = new Song("Candy shop","The Massacare","50 Cent",2006);
		Song s5 = new Song("Baby","Baby","Justin",2009);
		Song s6 = new Song("Persuit of Happiness","Man on moon","Kid Cudi",2010);
		
		
		System.out.println("Creating jukebox...");
		
		ArtistComparator artistCompare = new ArtistComparator();
		AlbumComparator  albumCompare = new AlbumComparator();
		TitleComparator titleCompare = new TitleComparator();
		YearComparator yearCompare = new YearComparator();
		
		ArrayList<Song> jukeBox = new ArrayList<Song>();
		
		/*Collection<String> jukeBox = new LinkedList<String>();
		Collection<String> jukeBox = new TreeSet<String>();
		Collection<String> jukeBox = new HashSet<String>();*/
		
		System.out.println("Adding song names to jukebox...");
		jukeBox.add(s1);
		jukeBox.add(s2);
		jukeBox.add(s3);
		jukeBox.add(s4);
		jukeBox.add(s5);
		jukeBox.add(s6);
		
		Collections.sort(jukeBox, albumCompare);
	
		System.out.println("Showing jukebox contents...");
		
		Iterator<Song> iter = jukeBox.iterator();
		
		while(iter.hasNext()) {
			Song x = iter.next();
			System.out.println("Song title  :"+x.getTitle());
			System.out.println("Song album  :"+x.getAlbum());
			System.out.println("Song artist :"+x.getArtist());
			System.out.println("Song year   :"+x.getYear());
			System.out.println("-----------------------");
		}
		
		
		

	}

}
