import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;


class MyFrame extends JFrame
{
	Song s1 = new Song("Persuit of Happiness","Man on moon","Kid Cudi",2010);
	Song s2 = new Song("Club cant handle me","Only one flo","Flo Rida",2011);
	Song s3 = new Song("Summer of 69","Summer of 69","Bryan Adams",1999);
	Song s4 = new Song("Candy shop","The Massacare","50 Cent",2006);
	Song s5 = new Song("Baby","Baby","Justin",2009);
	
	ArrayList<Song> al = new ArrayList<Song>();
	
	JTable jt ;
	JScrollPane jsp ;
	
	MyFrame() {
		Container con = getContentPane();
		setLayout(new FlowLayout());
		setSize(700,500);
		
		String col[]={"Album","Artist","Title","Years"};
		String str2[][]= {
							{new String(s1.getAlbum()),new String(s1.getArtist()),new String(s1.getTitle()),String.valueOf(s1.getYear())},
							{new String(s2.getAlbum()),new String(s2.getArtist()),new String(s2.getTitle()),String.valueOf(s2.getYear())},
							{new String(s3.getAlbum()),new String(s3.getArtist()),new String(s3.getTitle()),String.valueOf(s3.getYear())},
							{new String(s4.getAlbum()),new String(s4.getArtist()),new String(s4.getTitle()),String.valueOf(s4.getYear())},
							{new String(s5.getAlbum()),new String(s5.getArtist()),new String(s5.getTitle()),String.valueOf(s5.getYear())},
		};
		
		
		
		jt = new JTable(str2,col);
		jsp = new JScrollPane(jt,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		al.add(s5);
		
		
		
		con.add(jsp);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}

public class FrameTest {
	public static void main(String[] args) {
		MyFrame mfr = new MyFrame();
		mfr.setVisible(true);
	}

}
