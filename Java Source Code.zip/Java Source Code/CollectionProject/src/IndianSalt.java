
public @interface IndianSalt {

	String value();

}
