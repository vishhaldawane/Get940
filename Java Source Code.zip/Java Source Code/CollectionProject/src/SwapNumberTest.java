class SwapNumber<T>
{
	private T x;
	private T y;
	
	SwapNumber(T p, T q)
	{
		x = p;
		y = q;
	}
	
	void show() {
		System.out.println(" x "+x);
		System.out.println(" y "+y);
	}
	
	void swap()
	{
		System.out.println("Swapping Numbers.....");
		T temp=x;
		x=y;
		y=temp;
	}
}
/*
class SwapInt
{
	private int x;
	private int y;
	
	SwapInt(int p, int q)
	{
		x = p;
		y = q;
	}
	
	void show() {
		System.out.println(" x "+x);
		System.out.println(" y "+y);
	}
	
	void swap()
	{
		System.out.println("Swapping int.....");
		int temp=x;
		x=y;
		y=temp;
	}
}

class SwapFloat
{
	private float x;
	private float  y;
	
	SwapFloat(float p, float q)
	{
		x = p;
		y = q;
	}
	
	void show() {
		System.out.println(" x "+x);
		System.out.println(" y "+y);
	}
	
	void swap()
	{
		System.out.println("Swapping Float.....");
		float temp=x;
		x=y;
		y=temp;
	}
}*/

public class SwapNumberTest {
	public static void main(String[] args) {

		SwapNumber<Integer> sn1 = new SwapNumber<Integer>(10, 20);
		sn1.show();
		sn1.swap();
		sn1.show();
		
		System.out.println("--------------------------");
		
		SwapNumber<Float> sn2 = new SwapNumber<Float>(10.5f, 20.4f);
		sn2.show();
		sn2.swap();
		sn2.show();
		
		System.out.println("--------------------------");
		
		SwapNumber<Double> sn3 = new SwapNumber<Double>(100.5, 220.4);
		sn3.show();
		sn3.swap();
		sn3.show();

		System.out.println("--------------------------");
		
		SwapNumber<Character> sn4 = new SwapNumber<Character>('A','B');
		sn4.show();
		sn4.swap();
		sn4.show();

		
		/*SwapFloat sn1 = new SwapFloat(10.5f,20.6f);
		sn1.show();
		sn1.swap();
		sn1.show();
		System.out.println("-----------------");
		SwapInt sn2 = new SwapInt(10,20);
		sn2.show();
		sn2.swap();
		sn2.show();*/
		
	}

}
