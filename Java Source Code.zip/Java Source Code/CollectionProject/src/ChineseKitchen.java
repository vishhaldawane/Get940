
public @interface ChineseKitchen {

}
