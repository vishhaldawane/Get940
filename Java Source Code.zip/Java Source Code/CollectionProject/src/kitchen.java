
public class kitchen {

}
