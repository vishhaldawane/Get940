

 class Account
{
	void fun() {
		System.out.println("fun() of Account");
		Permission p = new Permission();
		p.permit();
	}
	
	class Permission { // inner class 
		void permit() {
			System.out.println("Account Permitted...");
		}
	}
}
 
 class Employee
 {
	 float basic;
	 
	 void salary() {
		 System.out.println("salary of employee");
	 }
 }

interface Abc
{
	int q=90; // by default public final static  
	
	class P { }
	P x = new P();
}

public class StaticClasses {
	
	
	public static void main(String[] args) {
		int i;
		i=0;
	/*	Account.Permission x = new Account().new Permission();
		x.permit();*/
		
		for (int i = 0; i < args.length; i++) {
			
			class A {
				
			}
			A a = new A();	
		}
		
		
		Employee e1 = new Employee();
		
		Employee e2 = new Employee()
		{ //code body of annonymous inner class
			float hra;
			
			void salary() {
				super.salary();
				System.out.println("salary of e2...annonymous");
			}
		}; //code end
		
		e1.salary();
		
		e2.salary();
		
				
		
			
	}
}





