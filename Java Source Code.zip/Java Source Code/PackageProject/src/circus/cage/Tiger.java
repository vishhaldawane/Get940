package circus.cage;

public class Tiger {
	public void jump() {
		System.out.println("Tiger is jumping...");
	}
}
