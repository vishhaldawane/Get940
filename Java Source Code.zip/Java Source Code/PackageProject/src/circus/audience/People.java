package circus.audience;

public class People {
	public void clap() {
		System.out.println("People clapping..");
	}
}
