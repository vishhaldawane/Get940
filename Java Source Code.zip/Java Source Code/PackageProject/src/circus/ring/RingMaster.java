package circus.ring;

public class RingMaster {
	public void instruct() {
		System.out.println("RingMaster is instructing.....");
	}
}
