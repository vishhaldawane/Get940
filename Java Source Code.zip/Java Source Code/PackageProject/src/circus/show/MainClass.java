package circus.show;

import circus.audience.People;
import circus.cage.Tiger;
import circus.ring.RingMaster;

public class MainClass {

	public static void main(String[] args) {
		RingMaster rm = new RingMaster();
		
		rm.instruct();
		
		Tiger t = new Tiger();
		
		t.jump();
		
		People p =new People();
		p.clap();

	}

}
