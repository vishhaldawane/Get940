package com.dept;



import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;
import org.hibernate.service.ServiceRegistry;

public class DepartmentTest {
	public static void main(String[] args) {
	
		
	}
}
class Cow
{
	Milk milkACow()
	{
		Milk m = new Milk();
		return m;
	}
}
class Milk {
	Curd coagulate() {
		return new Curd();
	}
}
class Curd {
	Butter churn() {
		return new Butter();
	}
}
class Butter {
	ClarifiedButter  boil() {
		return new ClarifiedButter();
	}
}
class ClarifiedButter {
	void eatDaily() {
		System.out.println("Eat daily....");
	}
}
