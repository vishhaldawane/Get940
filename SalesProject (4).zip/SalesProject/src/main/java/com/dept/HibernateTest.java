package com.dept;

public class HibernateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rose r = new Rose(); // direct way
		r.flowering();
		
		Flower f = new Rose();  // direct way, handle is of Flower
		f.flowering();
		
		//Flower f3 = new Flower();
		
		Flower f1 = Garden.getFlower();
		f1.flowering();
		
	}

}
abstract class Garden
{
	static Flower getFlower() {
		Flower f = new Rose();
		return f;
	}
}
interface Flower
{
	void flowering();
}
class Rose implements Flower
{
	public void flowering()
	{
		System.out.println("Rose is flowering...");
	}
}
