package com.dept;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;
import org.hibernate.service.ServiceRegistry;

/* functional interfaces
 * Serializable <-- no methods in it, marker interface
 * class Employee implements Serializable { }
 * Employee e = new Employee(101,"jack",5000);
 * ...writeObject(e); //store these details on teh harddrive
 * 
class MyBag<E> <-- declaration of a template class
{
	E is used in the declaration of x
	|
	E x;
	E y;
}
MyBag<Integer>  mg = new MyBag<Integer>();

class Process
{
	<E>  E fun() {
	} 
}
*/
public class BaseDAO {
	
	SessionFactory factory;
	
	BaseDAO() {
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		System.out.println("=>Service Registry.."+serviceRegistry);
		Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
		System.out.println("=>Meta Data.."+metadata);
		
		factory= metadata.getSessionFactoryBuilder().build();
		System.out.println("=>session factory.."+factory);
	}
	void save(Object o) { //user defined method here
		Session session = factory.getCurrentSession();
		try {
			System.out.println("=>session.."+session);
			Transaction tx = session.beginTransaction();
			System.out.println("=>transaction.."+tx);
			session.save(o); //session.save - sql insert query
			tx.commit();
		}
		finally {
			session.close();
		}
	}
	void saveOrUpdate(Object o) { //user defined method here
		Session session = factory.getCurrentSession();
		try {
			System.out.println("=>session.."+session);
			Transaction tx = session.beginTransaction();
			System.out.println("=>transaction.."+tx);
			session.saveOrUpdate(o); //session.save - sql insert query
			tx.commit();
		}
		finally {
			session.close();
		}
	}
	void remove(Object o) { //user defined method here
		Session session = factory.getCurrentSession();
		try {
			System.out.println("=>session.."+session);
			Transaction tx = session.beginTransaction();
			System.out.println("=>transaction.."+tx);
			session.remove(o); //session.save - sql insert query
			tx.commit();
		}
		finally {
			session.close();
		}
	}
	//interface A { }
	//everything including interfaces are the children of Object
	<E> E find(Class<E> classname, Serializable pk) { //user defined method here
		//A a ;
		//a.
		Session session = factory.getCurrentSession();
		try {
			System.out.println("=>session.."+session);
			Transaction tx = session.beginTransaction();
			System.out.println("=>transaction.."+tx);
			E e = session.find(classname,pk); //session.save - sql insert query
			tx.commit();
			return e;
		}
		finally {
			session.close();
		}
	}
	<E> List<E> getAll(String entityName) { //user defined method here
		Session session = factory.getCurrentSession();
		try {
			System.out.println("=>session.."+session);
			Transaction tx = session.beginTransaction();
			System.out.println("=>transaction.."+tx);
			Query query = session.createQuery(" from "+entityName);
			tx.commit();
			return query.getResultList();
		}
		finally {
			session.close();
		}
	}
}
