package com.dept;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="dept_hod")
public class HeadOfDepartment {
			//Passport
	@Id			
	@GeneratedValue
	private int hodId;
				
	@Column(name="hod_name",length=20) //db columns
	private String hodName;
	
	@Column(name="hod_address",length=20) //db columns
	private String hodAddress;
	
	@OneToOne 
	private Department dept; //dept_departmentnumber
	
	
	
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	
	public int getHodId() {
		return hodId;
	}
	public void setHodId(int hodId) {
		this.hodId = hodId;
	}
	public String getHodName() {
		return hodName;
	}
	public void setHodName(String hodName) {
		this.hodName = hodName;
	}
	public String getHodAddress() {
		return hodAddress;
	}
	public void setHodAddress(String hodAddress) {
		this.hodAddress = hodAddress;
	}
	
	
	
}
