import { BankDetail } from "../BankDetail";
import { Customer } from "../Customer";

export class Employee {
	  employeeNumber : number ;
	  employeeName : string ;
	  employeeSalary : number ;
	  customers: Customer[];
	  bankDetails: BankDetail[];
	  
}