export class Customer { 
	 customerId : number;
	 customerName : string;
	 city : string;
}