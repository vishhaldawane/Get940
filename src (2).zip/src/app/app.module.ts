import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { SqrtPipe } from './sqrt.pipe';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { FundTransferModule } from './fund-transfer/fund-transfer.module';
import { ViewPayeeComponent } from './fund-transfer/view-payee/view-payee.component';
import { ViewAllPayeesComponent } from './fund-transfer/view-all-payees/view-all-payees.component';
import { AddPayeeComponent } from './fund-transfer/add-payee/add-payee.component';
import { DeletePayeeComponent } from './fund-transfer/delete-payee/delete-payee.component';
import { AboutComponent } from './about/about.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { LogoutComponent } from './logout/logout.component';
import { HomeComponent } from './home/home.component';

@NgModule({ 
  declarations: [
    AppComponent,
    SqrtPipe,
    LoginComponent,
    RegisterComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    AboutComponent,
    PageNotFoundComponent,
    DashBoardComponent,
    LogoutComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule, 
    AppRoutingModule,
    FundTransferModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { } // like  a package 
