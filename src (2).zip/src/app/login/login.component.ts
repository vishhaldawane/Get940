import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from './login';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  allUsers: User[] = [
    {username: "sarita",password:"jane",isLoggedIn:false},
    {username: "julie",password:"jack",isLoggedIn:false},
    {username: "julia",password:"joy",isLoggedIn:false},
    {username: "rita",password:"jobby",isLoggedIn:false},
    {username: "meeta",password:"jimmy",isLoggedIn:false},
  ]; 

  myUser: User = new User();

  constructor(private router: Router) { 
    this.myUser.username='julie';
    this.myUser.password='jack'; 
    this.myUser.isLoggedIn=false;
  }
  foundTheUser: boolean ;
  userNotFoundMessage: string;

  ngOnInit(): void {  }
  authenticate() {
    this.foundTheUser=false;
    console.log("user..."+this.myUser.username);
    console.log("password..."+this.myUser.password);
    console.log("isLogged In..."+this.myUser.isLoggedIn);
     //some service call to authenticate the user... vis Services
     for(var theUser of this.allUsers) {
       if(theUser.username == this.myUser.username && theUser.password == this.myUser.password) {
          this.foundTheUser=true;
          this.myUser.isLoggedIn=true;
          break;         
       }
      //console.log("THEuser..."+theUser);
     // console.log("THEpassword..."+theUser.password);
      //console.log("THE User isLogged In..."+theUser.isLoggedIn);
     }
     if(this.foundTheUser==true) {
        this.userNotFoundMessage="User Found";
        this.gotoDashBoard(); 
     }
      else {
        this.userNotFoundMessage="User Not Found";
        this.router.navigate(['/home/login']);
      }
  }

  gotoDashBoard() {
    console.log("Welcome to the dashboard after authentication...");
    //some service calls can be made to fetch more user details
    this.router.navigate(['/dashboard']);  
  }
}
