import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FundTransfer1Service {

  constructor() { }
  checkFunds() {
    console.log('Checking funds via FundTransfer1Service');
  }
}
