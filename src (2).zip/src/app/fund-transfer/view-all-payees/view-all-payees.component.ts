import { Component, OnInit } from '@angular/core';
import { FundTransfer1Service } from '../fund-transfer1.service';

@Component({
  selector: 'app-view-all-payees',
  templateUrl: './view-all-payees.component.html',
  styleUrls: ['./view-all-payees.component.css']
})
export class ViewAllPayeesComponent implements OnInit {

  showAllPayees() {
    this.fts.checkFunds();
  }
  constructor(private fts: FundTransfer1Service) { }

  ngOnInit(): void {
  }

}
