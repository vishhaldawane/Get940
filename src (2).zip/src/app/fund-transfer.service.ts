import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class FundTransferService {
  constructor() { }
  addPayeeService() { console.log('add payee service is invoked..')  }
  viewPayeeService() { console.log('view payee service is invoked..') }
  deletePayeeService() {console.log('delete  payee service is invoked..') }
  viewAllPayeesService() {console.log('View All payees service is invoked..') }
}
