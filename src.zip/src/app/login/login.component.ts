import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  myUser: User = new User();
  constructor(private router: Router) { }
  ngOnInit(): void {  }
  authenticate() {
    console.log("First authenticate the user...");
    //some service call to authenticate the user... vis Services
    this.gotoDashBoard(); 
  }
  gotoDashBoard() {
    console.log("Welcome to the dashboard after authentication...");
    //some service calls can be made to fetch more user details
    this.router.navigate(['/dashboard:id']);  
  }
}
class User{  username: string;  password: string; }