import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPayeeComponent } from './add-payee/add-payee.component';
import { ViewPayeeComponent } from './view-payee/view-payee.component';
import { DeletePayeeComponent } from './delete-payee/delete-payee.component';
import { ViewAllPayeesComponent } from './view-all-payees/view-all-payees.component';



@NgModule({
  declarations: [ // they are the part of this module
    AddPayeeComponent,
    ViewPayeeComponent, 
    DeletePayeeComponent, 
    ViewAllPayeesComponent
  ],
  exports: [ //available to the outside world
    AddPayeeComponent,
    ViewPayeeComponent,
    DeletePayeeComponent,
    ViewAllPayeesComponent 
  ],
  imports: [
    CommonModule
  ]
})
export class FundTransferModule { }
