import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterComponent } from './register/register.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
/*
http://localhost:4200/about
http://localhost:4200/
http://localhost:4200/register
http://localhost:4200/login
http://localhost:4200/login/forgot
http://localhost:4200/login/reset
*/
const routes: Routes = [
  { path: 'about', component: AboutComponent },
  { path: '', redirectTo: '/about', pathMatch: 'full'},
  { path: 'register', component: RegisterComponent },

  { path: 'login', component: LoginComponent, 
    children: [
      { path: 'forgot', component: ForgotPasswordComponent },
      { path: 'reset', component: ResetPasswordComponent }
    ]
  },
  { path: 'dashboard', component: DashBoardComponent, 
    children: [
      { path: 'logout', component: AboutComponent }
    ]
  },  
  { path: '**', component: PageNotFoundComponent },
]; // let me know if u need screen switch to other pages

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
