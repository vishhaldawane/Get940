package com.majrul.embedded;

import org.junit.Test;

import com.majrul.util.BaseDao;

public class UserTest {


	@Test
	public void testCase2() {
			User2 u2 = new User2();
			u2.setId(123);
			u2.setFirstname("Yash");
			u2.setLastname("Samant");
			u2.setUsername("Yash");
			u2.setPassword("Yash123");
			
			u2.setCity1("Mumbai");
			u2.setStreet1("MGRoad");
			u2.setPin1("4120");
			
			u2.setCity1("Germany");
			u2.setStreet1("HitlerRd");
			u2.setPin1("5120");
			BaseDao dao = new BaseDao();
			dao.merge(u2);
			
	}
	@Test
	public void testCase1() { 
		User  u = new User();
		u.setId(88);
		u.setFirstname("Majrul");
		u.setLastname("Ansari");
		u.setUsername("majrul");
		u.setPassword("majrul123");
		
		Address officeAddress = new Address();
		officeAddress.setCity("Mumbai1");
		officeAddress.setStreet("Vikhroli");
		officeAddress.setZipcode("400083");
		
		Address homeAddress = new Address();
		homeAddress.setCity("Pune2");
		homeAddress.setStreet("LaxmiRoad");
		homeAddress.setZipcode("411083");

		u.setBillingAddress(officeAddress);
		u.setHomeAddress(homeAddress);

		BaseDao dao = new BaseDao();
		dao.merge(u);
	}
}
