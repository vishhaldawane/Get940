package com.majrul.embedded;

public class StaticTest {
	public static void main(String[] args) {
		System.out.println("hello main");
		
		MyConnection m1  = new MyConnection(1);
		MyConnection m2  = new MyConnection(2,3);
		MyConnection m3  = new MyConnection(4,5,6);
		
		System.out.println("End main");
	}
}

class MyConnection
{
	static {
		System.out.println("setting activities first time...");
	}
	
	{
		System.out.println("Annonymous block....");
	}
	
	MyConnection(int i) {
		System.out.println("MyConnection (1) ctor...");
	}
	
	MyConnection(int i, int j) {
		System.out.println("MyConnection (2) ctor...");
	}
	
	MyConnection(int i,int j, int k) {
		System.out.println("MyConnection (3) ctor...");
	}
	static void far() {
		System.out.println("Hello far...");
	}
	
	void fun() {
		System.out.println("Hello fun...");
	}
	
}
